<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Area extends CI_Controller {
    
	public function __construct()
    {
        parent::__construct();
        if ( ! isset($_SESSION['user_email'])) {
			redirect('auth/login');
		}
    }

	public function edit($id)
	{   
        $user_id = $_SESSION['user_id'];

        $data = [
            'user' => $this->user_model->get_user($user_id),
            'districts' => $this->district_model->get(),
            'area' => $this->area_model->get_area($id),    
        ];
		$this->load->view('superuser/area/edit', $data);
	}

	public function delete($id)
	{	
        $user_id = $_SESSION['user_id'];
        
        $data = [
            'user' => $this->user_model->get_user($user_id),
            'area' => $this->area_model->get_area($id)    
        ];        
        $this->load->view('superuser/area/delete', $data);
	}

    public function purge()
    {
        $this->area_model->delete();

        $tempdata = array(
            'success_msg' => '<strong>Area Deleted Successfully!</strong>'
        );    

        $expire = 5;
        $this->session->set_tempdata($tempdata, NULL, $expire);          

        redirect('admin/list_areas');
    }

    public function update($id)
    {   

        $data = [
            'districts' => $this->district_model->get(),
            'area' => $this->area_model->get_area($id)
        ];

        // do this if any form input is invalid
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('superuser/area/edit', $data);
        }  
        else 
        {  
            $this->area_model->update($id);

            $tempdata = array(
                'success_msg' => '<strong>Area Updated Successfully!</strong>'
            );    

            $expire = 5;
            $this->session->set_tempdata($tempdata, NULL, $expire);        

            redirect('admin/list_areas');
        }
    }

}
