<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->output->enable_profiler(TRUE);
    }	

    public function listing_beta()
    {		
			/*
			Author: imtaher
			Website Title: Stack Overflow
			URL: https://stackoverflow.com/questions/40778683/multiple-image-upload-with-codeigniter 
			*/
			$image_info = array();
			$count_images = count($_FILES['image_file']['name']);
			
			for($i = 0; $i<$count_images; $i++)
			{
				$_FILES['file']['name'] = $_FILES['image_file']['name'][$i];
				$_FILES['file']['tmp_name'] = $_FILES['image_file']['tmp_name'][$i];
				$_FILES['file']['size'] = $_FILES['image_file']['size'][$i];
				
				// configuration
				$config = [
					'upload_path' => IMAGE_GALLER,
					'allowed_types' => 'gif|jpg|png|jpeg',
					'max_size' => 1000,
					'encrypt_name' => TRUE
				];

				$this->upload->initialize($config);
				if( ! $this->upload->do_upload('file'))
				{
					$error = array('error' => $this->upload->display_errors());
				}		

				if($this->upload->do_upload('file'))
				{
					$img_data = $this->upload->data();
					$upload_img_data[$i]['image'] = $img_data['file_name'];
					//$upload_img_data[$i]['created_at'] = date("Y-m-d H:i:s");
				}

			}

			if( ! empty($upload_img_data))
			{	
				var_dump($count_images);
				var_dump($upload_img_data);
				//$this->listing_model->store_images($image_config);
				// insert image info into database
				$this->listing_model->chaos($upload_img_data);
			}			

			/*if($this->upload->do_upload('file'))
			{
				$data = $this->upload->data();

				$image_config[$i]['image_file'] = $data['file_name'];
				for($i = 0; $i<$count_images; $i++)
				{
					$image_arr[$i]['image_file'] = $data['file_name'][$i];
					$array[] = array('image' => $image_arr[$i]['image_file']);
				}
			
				// check what's in $data
			var_dump($data);	
			}*/
    }

	public function listing()
	{	
		$id = $_SESSION['user_id'];

		$data = [
			'user' => $this->user_model->get_user($id),
			'districts' => $this->district_model->get(),
			'areas' => $this->area_model->get(),
		];

        if ($this->form_validation->run() == FALSE)
        {    
			$data['error'] = TRUE;
            $this->load->view('normal_user/upload_listing', $data);
        } 
        else 
        {	
			// image upload
			//set configurations
			$config = [
				'upload_path' => MAIN_UPLOADS,
				'allowed_types' => 'gif|jpg|png|jpeg',
				'max_size' => 1000,
				'encrypt_name' => TRUE
			];

			// upload the image 
			$this->upload->initialize($config);
			// if image was not uploaded do this			
            if ( ! $this->upload->do_upload('image'))
            {
                $id = $_SESSION['user_id'];

				$data = [
				'user' => $this->user_model->get_user($id),
				'districts' => $this->district_model->get(),
				'areas' => $this->area_model->get(),		
				'error' => array('error' => $this->upload->display_errors()),		
				];

                $this->load->view('normal_user/upload_listing', $data);
            }
			// if image was uplaoded, do this
            else
            {	
				//get image name and store listing in database
                $image_info = $this->upload->data();
                $image = $image_info['file_name'];
                $this->listing_model->create($image);

				// get info on most recent listing upload by user
				$listing = $this->subscription_model->get_listing();

				// get the subscriber's emails
				$subscribers = $this->subscription_model->get_subscribers();

				// if no subscribers exist, do not send any email
				if ( ! empty ($subscribers))
				{
				
					// push each email to an array	
					$subs_email = array();
					foreach ($subscribers as $emails) {
						$subs_email[] = $emails['user_email'];
					}

					$config = array(
						'protocol' => 'smtp',
						'smtp_host' => 'ssl://smtp.gmail.com',
						'smtp_port' => '465',
						'smtp_timeout' => '7',
						'smtp_user' => 'real.estate.betamw@gmail.com',
						'smtp_pass' => EMAIL_PASS,
						'charset' => 'utf-8',
						'newline' => "\r\n",
						'mailtype' => 'html',
					);

					$this->email->initialize($config);

					$this->email
						->from('real.estate.betamw@gmail.com', 'The Nation Real Estate')
						->to($subs_email)
						->subject('New listing in '.$listing['district'] . ', ' . $listing['area'])
						->message($listing['name'] . ' . Here is a link to the property ' . site_url('listings/'.$listing['slug']));
					// if sending emailed failed show the error	
					if ( ! $this->email->send())
					{	
						//show_error($this->email->print_debugger());
						$this->load->view('errors/sys_admin/email_error');
					} 
				}	
				// show success message
				$tempdata = array(
                    'success_msg' => '<strong>Listing Uploaded Successfully!</strong> Click <a class=alert-link href= ' . site_url('listing/'.$listing['slug']) . '>here</a> to view it',
				);    
		
				$expire = 5;
				$this->session->set_tempdata($tempdata, NULL, $expire);   				
				$this->load->view('normal_user/success');
            }
        }  		
	}

}    