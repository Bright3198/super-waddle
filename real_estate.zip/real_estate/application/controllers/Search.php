<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->output->enable_profiler(TRUE);
    }    

    #August 3 2:11PM (Fully Functional)
    public function index()
        {
            $district = $this->input->get('district');
            $area = $this->input->get('area');
            $baths = $this->input->get('baths');
            $rooms = $this->input->get('rooms');
            $type = $this->input->get('type');
            $price_min = 0;
            $price_max = 0;

            if ( ! empty ($_GET['price_min'])) {
                $price_min = $this->input->get('price_min');
            }

            if ( ! empty ($_GET['price_max'])) {
                $price_max = $this->input->get('price_max');
            }            

            $count = $this->listing_model->count_search($district, $area, $rooms, $baths, $type, $price_min, $price_max);

            $config = [
            'base_url' => site_url(). '/search/index/',
            'total_rows' => $count,
            'per_page' => 9,
            'attributes' => array('class' => 'page-link', 'style' => 'color: green;'),
            'suffix' => '/?search=', 
            'first_url' => site_url(). '/search/index/search/?search=',
            'uri_segment' => 3,
            'enable_query_strings' => TRUE,
            'prev_link' => '&laquo', 
            'next_link' => '&raquo',     
            'cur_tag_open' => '<li class="active"><a class="page-link" style="color: green;">',
            'cur_tag_close' => '</li></a>',  
            'next_tag_open' => '<li>',
            'next_tag_close' => '</li>',
            'first_tag_open' => '<li>',
            'first_tag_close' => '</li>',                
            'last_tag_open' => '<li>',
            'last_tag_close' => '</li>',               
            'prev_tag_open' => '<li>',
            'prev_tag_close' => '</li>',
            'num_tag_open' => '<li>',
            'num_tag_close' => '</li>',               
            ];

            $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0; 

            $this->pagination->initialize($config);             

            $data = [
                'count' => $count,
                'search_results' => $this->listing_model->search($config['per_page'], $page, $district, $area, $rooms, $baths, $type, $price_min, $price_max),          
                'links' => $this->pagination->create_links(),
                'districts' => $this->district_model->get(),
                'areas' => $this->area_model->get()
            ];  
                $this->load->view('normal_user/search/index', $data);        
        }

}