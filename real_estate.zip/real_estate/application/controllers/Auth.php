<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	
    public function create_superuser()
    {
        $this->auth_model->create_user($permissions = 0);
    }

	public function signup()
	{
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('normal_user/signup');
		} 
		else		
		{
		$this->auth_model->create_user($permissions = 2);
		$email = $this->input->post('email');
		$_SESSION = array('user_email' => $email, 'user_permissions' => 2);
		redirect('user/login_success');
		}
	}	

	public function password_check() 
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		// check if any rows match $email
		$auth = $this->auth_model->auth($email);

		if( ! empty($auth)){
			// fetch hashed password from database
			$hash_password = $auth['password'];

			if (password_verify($password, $hash_password)){
				return TRUE;
			}
			else
			{ 	
			return FALSE;
			}
		}	
	}	

	public function user_exists_check()
	{
		$email = $this->input->post('email');
		$count = $this->auth_model->check_user_exists($email);
		if ($count === 1) {
			return TRUE;
		}  else {
			return FALSE;
		}
	}	

	public function login()
	{
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('normal_user/login');
		} 
		else
		{
			$email = $this->input->post('email');
			$password = $this->input->post('password');

			$auth = $this->auth_model->auth($email);

			$hash_password = $auth['password'];

			if (password_verify($password, $hash_password)){
				$_SESSION = array('user_email' => $auth['email'], 'user_permissions' => $auth['permissions'], 'user_id' => $auth['id']);
				redirect('user/login_success');
			} 
		}	
	}

}
