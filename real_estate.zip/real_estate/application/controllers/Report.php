<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {
    
	public function __construct()
    {
        parent::__construct();
        // only set to true when troubleshooting php and db
        // setting to true messes with json data and graphs won't show
        $this->output->enable_profiler(FALSE);
        if ( ! isset($_SESSION['user_email'])) {
			redirect('user/login');
		} elseif (isset ($_SESSION['user_email'])) {
			$permissions = $_SESSION['user_permissions'];

			if ($permissions != 0) {
				redirect('user/access_denied');
			}
		}
    }

    public function index()
    {   
        $mo = $this->input->post('month');

        $data = [
            'blantyre' => $this->report_model->listing_clicks($district = 'Blantyre'),
            'lilongwe' => $this->report_model->listing_clicks($district = 'Lilongwe'),    
            'month_select' => $this->report_model->month_report($mo),
            'users_registered_lw' => $this->report_model->users_registered($days = 7),  
            'listings_posted_lw' => $this->report_model->listings_posted($days = 7),
            'users_registered_mo' => $this->report_model->users_registered($days = 30),
            'listings_posted_mo' => $this->report_model->listings_posted($days = 30),
            'lpd' => $this->report_model->listings_per_district(),
        ];

        $this->load->view('reports/index', $data);
    }

    public function listings_per_district()
    {   
        // fetch district name and number of listings per district
        $lpd = $this->report_model->listings_per_district();

        // put the data into an array
        $data = array();
        foreach ($lpd as $row) {
            $data[] = $row;
        }
        
        // encode array as JSON
        echo json_encode($data);
    }

    public function most_clicked_listings()
    {
        //fetch district name and number of clicks
        $mcl = $this->report_model->listing_clicks($district = 'Blantyre');

        // put the data into an array
        $data = array();
        foreach ($mcl as $row) {
            $data[] = $row;
        }
        
        // encode array as JSON
        echo json_encode($data);

    }

}    