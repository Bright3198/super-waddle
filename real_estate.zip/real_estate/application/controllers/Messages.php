<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Messages extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if ( ! isset($_SESSION['user_email'])) {
			redirect('user/login');
		}        
        $this->output->enable_profiler(TRUE);
    }

    public function compose($receiver_id)
    {
        $data = [
        'user' => $this->messages_model->get_user($receiver_id),    
        ];

        $this->load->view('normal_user/messages/compose', $data);
    }

    public function store($receiver_id)
    {
        if ($this->form_validation->run() == FALSE) {
            $count_result = $this->messages_model->count_chat($receiver_id);

            $data = [
                'chat' => $this->messages_model->get_chat($receiver_id, $count_result),
                'chat_count' => $this->messages_model->count_chat($receiver_id),
                'user' => $this->messages_model->get_chat_details($receiver_id),    
                ];

            $this->load->view('normal_user/messages/chat', $data);
        } else {
            $this->messages_model->create($receiver_id);
        }
    }

    public function inbox()
    {   
        $get_received_interactions = $this->messages_model->get_receieved_interactions();
        $get_sent_interactions = $this->messages_model->get_sent_interactions();

        // push each received interaction to an array	
        $received = array();
        foreach ($get_received_interactions as $sender) {
            $received[] = $sender['sender_id'];
        }

        // push each sent interaction to an array	
        $sent = array();
        foreach ($get_sent_interactions as $receiver) {
            $sent[] = $receiver['receiver_id'];
        }

        $total_interactions = array_merge($received, $sent); // merge arrays

        $unique_interactions = array_unique($total_interactions); // remove duplicate interactions

        $count_interactions = count($unique_interactions); // count_interactions

        $yesterday = date("Y-m-d", strtotime("-1 days")); // yesterday's date as string

        $today = date("Y-m-d", strtotime("now")); // today's date as string

        for ($i = 0; $i<$count_interactions; $i++)
        {   
            $id = $unique_interactions[$i];
            $created = $this->messages_model->get_latest_msg_time($id); // get msg created time

            // get latest interaction msg info using created time
            $msg_created_time = $created['created'];

            /*--- convert time to more readable format ---*/
            // convert string to date object
            $msg_date = date_create($msg_created_time);
            $curr_date = date_create(date("Y-m-d 00:00"));

            // get difference between message time and current date
            $msg_date_str = date("Y-m-d", strtotime($msg_created_time)); // message date to string
            $week_later_from_msg_time = date("Y-m-d", strtotime("$msg_date_str+7 days")); // 1 week from msg sent time string
            $week_later_from_msg_date = date_create($week_later_from_msg_time); 
            $today_date = date_create($today); // today's string date as dateTime

            // compare today to when it will be a week later and store values in array
            //$date_diff = (array) date_diff($today_date, $week_later_from_msg_date);            

            // show date format depending on which case is met
            if ($msg_date_str === $today) 
            {       
                $time_display = date("H:i", strtotime($msg_created_time)); // check if message date matches today's date and show only hours and minutes
            } 
            elseif ($msg_date_str === $yesterday) // check if message date matches yesterday's
            {       
                $time_display = 'Yesterday';
            }
            elseif ($today_date < $week_later_from_msg_date) // within a week
            {
                $time_display = date("D", strtotime($msg_created_time));
            }                  
            elseif ($today_date >= $week_later_from_msg_date) // when it is or 1 week is exceeded
            {
                $time_display = date("d/m/Y", strtotime($msg_created_time));
            }  

            $other_user = $this->messages_model->get_other_user_name($id); // get the other chat user

            $message = $this->messages_model->get_latest_msg_info($id, $msg_created_time); // get message
            $messages[$i] = [
                'id' => $message['id'],
                'message' => $message['message'],
                'sender_id' => $message['sender_id'],
                'receiver_id' => $message['receiver_id'],
                'created_at' => $message['created_at'],
                'read_status' => $message['read_status'],
                'chat_name' => $other_user['name'],
                'chat_id' => $other_user['id'],
                'time_display' => $time_display
            ];
        }
        // if user has no messages
        if ($i == NULL) 
        {
            echo 'no messages';
        }
        else 
        {
            $data = [
                'latest_msg' => $messages,
                'messages' => $this->messages_model->get_messages()    
            ];

            $this->load->view('normal_user/messages/inbox', $data);
        }
    }    

    public function view($id)
    {
        $count_result = $this->messages_model->count_chat($id);

        $data = [
            'chat' => $this->messages_model->get_chat($id, $count_result),
            'chat_count' => $this->messages_model->count_chat($id),
            'user' => $this->messages_model->get_chat_details($id),    
        ];

        $this->load->view('normal_user/messages/chat', $data);
    }
}    