<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class District extends CI_Controller {
    
	public function __construct()
    {
        parent::__construct();
        if ( ! isset($_SESSION['user_email'])) {
			redirect('auth/login');
		}
    }

	public function edit($id)
	{   
        $user_id = $_SESSION['user_id'];

        $data = [
            'user' => $this->user_model->get_user($user_id),
            'district' => $this->district_model->get_district($id)    
        ];
		$this->load->view('superuser/district/edit', $data);
	}

	public function delete($id)
	{	
        $user_id = $_SESSION['user_id'];
        
        $data = [
            'user' => $this->user_model->get_user($user_id),
            'district' => $this->district_model->get_district($id)    
        ];        
        $this->load->view('superuser/district/delete', $data);
	}

    public function purge()
    {
        $this->district_model->delete();

        $tempdata = array(
            'success_msg' => '<strong>District Deleted Successfully!</strong>'
        );    

        $expire = 5;
        $this->session->set_tempdata($tempdata, NULL, $expire);          

        redirect('admin/list_districts');
    }

    public function update($id)
    {   

        $data = [
            'district' => $this->district_model->get_district($id)
        ];

        // do this if any form inputs is invalid
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('superuser/district/edit', $data);
        }  
        else 
        {  
            $this->district_model->update();

            $tempdata = array(
                'success_msg' => '<strong>District Updated Successfully!</strong>'
            );    

            $expire = 5;
            $this->session->set_tempdata($tempdata, NULL, $expire);        

            redirect('admin/list_districts');
        }
    }

}
