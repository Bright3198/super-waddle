<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->output->enable_profiler(TRUE);
    }

	public function access_denied()
	{
		$this->load->view('messages/access_denied');
	}

	public function signup()
	{
		$this->load->view('normal_user/signup');
	}

	public function login_success()
	{
		if (isset($_SESSION['user_email'])){
			$this->load->view('normal_user/login_success');
		} 
		else
		{
		redirect('user/login');
		}		
	}

	public function login()
	{	
		if (isset($_SESSION['user_email'])){
			$this->load->view('normal_user/login_success');
		} 
		else
		{
		$this->load->view('normal_user/login');
		}
	}

	public function logout()
	{
		session_destroy();
		redirect('user/login');
	}	

	public function listings()
	{
		if( ! isset($_SESSION['user_email'])) {
			redirect('user/login');
		}

		$data = [
			'listings' => $this->listing_model->get_user_listings(),
		];

		$this->load->view('normal_user/listings/manage', $data);
	}

	public function upload_listing()
	{	
		if( ! isset($_SESSION['user_email'])) {
			redirect('user/login');
		}

		$id = $_SESSION['user_id'];

		$data = [
		'user' => $this->user_model->get_user($id),	
		'districts' => $this->district_model->get(),
		'areas' => $this->area_model->get(),
		];
		
		if(isset($_SESSION['user_email']))
		{
			$permissions = $_SESSION['user_permissions'];

			if($permissions == 2) 
			{
				echo 'You cannot do shit';
			} 
			elseif($permissions == 0 || $permissions == 1)
			{
				$this->load->view('normal_user/upload_listing', $data);
			} 
		} 
		else { redirect('user/login'); }
	}

	public function profile()
	{	
		if( ! isset($_SESSION['user_email'])) {
			redirect('user/login');
		}

		$id = $_SESSION['user_id'];

		$data = [
		'user' => $this->user_model->get_user($id),
		'user_listings' => $this->listing_model->get_listings($id)	
		];

		$this->load->view('normal_user/profile/index', $data);
	}

}