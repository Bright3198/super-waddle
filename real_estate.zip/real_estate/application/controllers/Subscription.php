<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscription extends CI_Controller {

	public function store()
	{   
        if( ! isset($_SESSION['user_email'])) {
            redirect('auth/login'); 
        }

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('already_subbed');
        } else {
            $this->subscription_model->create();
        }
	}

    public function unsubscribe()
    {
        $this->subscription_model->soft_delete();
        $slug = $this->input->post('slug');
        redirect('listings/'.$slug);
    }

    public function check_if_extists()
    {
        $check = $this->subscription_model->check_if_exists();
        if ($check === 1) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

}