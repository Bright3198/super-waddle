<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Listings extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->output->enable_profiler(TRUE);
    }
    
    public function index()
    {   
        $user_id = 0;
        if (isset($_SESSION['user_email'])) {
            $user_id = $_SESSION['user_id'];
        }

        $data = [
            'user' => $this->user_model->get_user($user_id),   
            'listings' => $this->listing_model->get_listings(),    
            'districts' => $this->district_model->get(),
            'areas' => $this->area_model->get()
        ];

        $this->load->view('normal_user/index', $data);
    }

    public function view($slug)
    {   
        if (isset($_SESSION['user_email']))
        {
            $email = $_SESSION['user_email'];
        } else {
            $email = NULL;
        }

        $listing = $this->listing_model->get($slug);
        $area = $listing['area'];
        $district = $listing['district'];
        $click_count = $listing['click_count'];
        $new_click_count = $click_count+1;

        $data = [
            'click_count' => $click_count,
            'click' => $new_click_count,
            'listing_item' => $this->listing_model->get($slug),
            'count' => $this->subscription_model->check_if_exists($email, $area, $district),
        ];

        $this->listing_model->update_click_count($new_click_count, $slug);
        $this->load->view('normal_user/listings/view', $data);
    }

    // this is jsut a test, remove asap
    public function property($slug)
    {   
        if (isset($_SESSION['user_email']))
        {
            $email = $_SESSION['user_email'];
        } else {
            $email = NULL;
        }

        $listing = $this->listing_model->get($slug);
        $area = $listing['area'];
        $district = $listing['district'];
        $click_count = $listing['click_count'];
        $new_click_count = $click_count+1;

        $data = [
            'click_count' => $click_count,
            'click' => $new_click_count,
            'listing' => $this->listing_model->get($slug),
            'count' => $this->subscription_model->check_if_exists($email, $area, $district),
        ];

        $this->listing_model->update_click_count($new_click_count, $slug);
        $this->load->view('normal_user/listings/property', $data);
    }    

    public function edit($id)
    {
        //Verify user owns listing
        $verification = $this->listing_model->verify_ownership($id);

        if ($verification === 1)
        {   
            $get_listing = $this->listing_model->get_listing($id);
            $data = [
                'districts' => $this->district_model->get(),
                'areas' => $this->area_model->get(),
                'listing' => $get_listing,
            ];

            $this->load->view('normal_user/listings/edit', $data);
        } else {
            show_404();
        } 
    }

    public function update($id)
    {
        $verification = $this->listing_model->verify_ownership($id);

        $get_listing = $this->listing_model->get_listing($id);
        $districts = $this->district_model->get();
        $areas = $this->area_model->get();

        $data = [
            'listing' => $get_listing,
            'districts' => $districts,
            'areas' => $areas,
        ];

        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('normal_user/listings/update_form_error', $data);
        } 
        else 
        {        
            if ($verification === 1)
            {   
                $this->listing_model->update($id);
                $tempdata = array(
                    'success_msg' => '<strong>Listing Updated Successfully!</strong> Click <a class=alert-link href= ' . site_url('listing/'.$get_listing['slug']) . '>here</a> to view it',
                );    

                $expire = 5;
                $this->session->set_tempdata($tempdata, NULL, $expire);
                
                redirect('user/listings');	
            } 
            else { show_404(); }
        }             
    }

    public function delete($id)
    {
        //Verify user owns listing
        $verification = $this->listing_model->verify_ownership($id);

        $get_listing = $this->listing_model->get_listing($id);
        $districts = $this->district_model->get();
        $areas = $this->area_model->get();

        $data = [
            'listing' => $get_listing,
            'districts' => $districts,
            'areas' => $areas,
        ];        

        if ($verification === 1)
        {
            $this->load->view('normal_user/listings/delete', $data);
        } 
        else { show_404(); } 
    }

    public function purge($id)
    {
        //Verify user owns listing
        $verification = $this->listing_model->verify_ownership($id);

        if ($verification === 1)
        {
            $this->listing_model->delete($id);

            $tempdata = array(
                'success_msg' => '<strong>Listing Deleted Successfully!</strong>'
            );    

            $expire = 5;
            $this->session->set_tempdata($tempdata, NULL, $expire);
            
            redirect('user/listings');	            
        } 
        else { show_404(); }         
    }

}