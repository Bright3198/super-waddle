<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    
	public function __construct()
    {
        parent::__construct();
        if ( ! isset($_SESSION['user_email'])) {
			redirect('user/login');
		} elseif (isset ($_SESSION['user_email'])) {
			$permissions = $_SESSION['user_permissions'];

			if ($permissions != 0) {
				redirect('user/access_denied');
			}
		}
    }

	public function index()
	{	
		$data = [
			'users_registered_lw' => $this->report_model->users_registered($days = 7),  
            'listings_posted_lw' => $this->report_model->listings_posted($days = 7),
            'users_registered_mo' => $this->report_model->users_registered($days = 30),
            'listings_posted_mo' => $this->report_model->listings_posted($days = 30),
			'subscriptions_per_district' => $this->report_model->subscriptions_per_district(),
		];

		$this->load->view('superuser/index', $data);
	}

	public function god_mode()
	{
		$this->load->view('superuser/create');
	}

	public function list_users()
	{	
		$data = [
		'user' => $this->user_model->get_users(),	
		];
		$this->load->view('superuser/list_of_users', $data);
	}

	public function subscribers()
	{
		$data = [
			'subscribers' => $this->subscription_model->get()
		];

		$this->load->view('superuser/subscriptions', $data);
	}

	public function edit_user($id)
	{	
		$data = [
			'user' => $this->user_model->get_user($id),	
		];
		$this->load->view('superuser/edit_user', $data);
	}

	public function update_user_permissions($id)
	{	
		// check if input sent is empty
		if( ! empty($_POST['check_permissions']))
		{
			$permissions = 1;
		} 
		else
		{
			$permissions = 2;	
		}

		$this->user_model->update_user_permissions($id, $permissions);

        $tempdata = array(
            'success_msg' => '<strong>User Status Updated Successfully!</strong>'
        );    

        $expire = 5;
        $this->session->set_tempdata($tempdata, NULL, $expire);   		

		redirect('admin/list_users');
	}	

	public function create_district()
	{
		$this->load->view('superuser/district/create');
	}

	public function store_district()
	{
		if ($this->form_validation->run() == FALSE) {
			$this->load->view('superuser/district/create');
		}	
		else 
		{	
			$this->district_model->create();
			redirect('admin/list_districts');
		}
	}

	public function create_area()
	{
		$data = [
			'districts' => $this->district_model->get(),
		];		

		$this->load->view('superuser/area/create', $data);
	}

	public function store_area()
	{
		if ($this->form_validation->run() == FALSE) {
			$data = [
				'districts' => $this->district_model->get(),
			];			
			$this->load->view('superuser/area/create', $data);
		} 
		else 
		{			
			$this->area_model->create();

			$tempdata = array(
				'success_msg' => '<strong>New Area Added Successfully!</strong>'
			);    
	
			$expire = 5;
			$this->session->set_tempdata($tempdata, NULL, $expire);   			
	
			redirect('admin/list_areas');
		}
	}	

	public function list_districts()
	{ 
		$user_id = $_SESSION['user_id'];

		$data = [
			'user' => $this->user_model->get_user($user_id),	
			'districts' => $this->district_model->get(),
		];
		$this->load->view('superuser/district/list_all', $data);
	}

	public function list_areas()
	{
		$data = [
			'areas' => $this->area_model->get(),
		];
		$this->load->view('superuser/area/list_all', $data);
	}


}
