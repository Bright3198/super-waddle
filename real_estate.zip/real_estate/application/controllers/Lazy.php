<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lazy extends CI_Controller {

	public function __construct()
    {
        parent::__construct();   
        $this->output->enable_profiler(TRUE);
    }
    
	public function index()
	{   
        /*
        To avoid error undefined variable on array key user in $data,
        this ($user_id = 0) is use instead
        */ 
        $user_id = 0;
        if (isset($_SESSION['user_email'])) {
            $user_id = $_SESSION['user_id'];
        }

        $data = [
            'user' => $this->user_model->get_user($user_id),
            'listings' => $this->listing_model->get_listings(),
            'links' => array(
                'user/signup', 
                'user/login',
                'user/login_success',
                'user/upload_listing',
                'admin/create_district',
                'admin/list_districts',
                'admin/create_area',
                'admin/list_areas',
                'listings',
                'messages/inbox',
                'report',
                'admin',
                'admin/subscribers',
                'user/listings',
            ),
        ];    
		$this->load->view('a_bunch_of_links', $data);
	}

    public function upload_test()
    {
        $this->load->view('superuser/tests/multiplicity_upload');
    }
}