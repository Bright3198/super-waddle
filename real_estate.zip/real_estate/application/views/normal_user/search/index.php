<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Search Results</title>
        <link rel="stylesheet" href="<?= site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/style.css')?>">

</head>
<body>
	<!-- NAV -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="<?= site_url()?>">The Nation</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
            <a class="nav-item nav-link" href="<?= site_url()?>">Home <span class="sr-only">(current)</span></a>
            <a class="nav-item nav-link" href="<?= site_url('search/index?type=Rent')?>">For Rent</a> 
            <a class="nav-item nav-link" href="<?= site_url('search/index?type=Sale')?>">For Sell</a> 
            <?php if (isset($_SESSION['user_email'])):?>
            <a class="nav-item nav-link" href="<?= site_url('messages/inbox')?>">Messages</a>   
            <a class="nav-item nav-link" href="<?= site_url('user/logout')?>">Logout</a>  
            <?php endif;
            if ( ! isset($_SESSION['user_email'])):?>
            <a class="nav-item nav-link" href="<?= site_url('user/signup')?>">Signup</a>  
            <a class="nav-item nav-link" href="<?= site_url('user/login')?>">Login</a>  
            <?php endif ?>          

            </div>
        </div>
    </nav> 

    <div class ="container">   
        <form style="margin-top: 15px;" action="<?= site_url('search/index');?>" method="get">
        <label>District:</label>
        <select name="district">
            <?php if ( ! empty($_GET['district'])):
            $option = $_GET['district'];?>   
            <option value="<?= $option; ?>"><?= $option; ?></option>
            <?php endif; ?>    
            <option value="0">Any</option>
            <?php foreach ($districts as $item): ?>
                <option value="<?= $item['name']; ?>"><?= $item['name']; ?></option>
            <?php endforeach?>    
        </select>

        <label>Area:</label>
        <select name="area">
            <?php if ( ! empty($_GET['area'])):
            $option = $_GET['area'];?>   
            <option value="<?= $option; ?>"><?= $option; ?></option>
            <?php endif; ?>            
            <option value="0">Any</option>
            <?php foreach ($areas as $item): ?>
                <option value="<?= $item['name']; ?>"><?= $item['name']; ?></option>
            <?php endforeach?>        
        </select>

        <label>Baths:</label>
        <select name="baths">
            <?php if ( ! empty($_GET['baths'])):
            $option = $_GET['baths'];?>   
            <option value="<?= $option; ?>"><?= $option; ?></option>
            <?php endif; ?>            
            <option value="0">Any</option>
            <?php for ($x = 1; $x <= 10; $x++):?>
                <option value="<?= $x?>"><?= $x;?></option>
            <?php endfor ?>
        </select>

        <label>Bedrooms:</label>
        <select name="rooms">
            <?php if ( ! empty($_GET['bedrooms'])):
            $option = $_GET['bedrooms'];?>   
            <option value="<?= $option; ?>"><?= $option; ?></option>
            <?php endif; ?>            
            <option value="0">Any</option>
            <?php for ($x = 1; $x <= 10; $x++):?>
                <option value="<?= $x?>"><?= $x?></option>
            <?php endfor ?>        
        </select>  

        <label>Type:</label>
        <select name="type">
        <?php if ( ! empty($_GET['type'])):
            $option = $_GET['type'];?>   
            <option value="<?= $option; ?>"><?= $option; ?></option>
            <?php endif; ?>             
            <option value="0">Rent or Sale</option>
            <option value="Rent">Rent</option>
            <option value="Sale">Sale</option>    
        </select>

        <label>Min Price:</label>
        <input style="width: 120px;" type="text" name="price_min" placeholder="Leave Blank or">       

        <label>Max Price:</label>
    <input style="width: 120px;" type="text" name="price_max" placeholder="e.g. 10000000">         
    
    <button style="background-color: #000; color: #fff; border-radius: 15px;" type="submit">Search!💥</button>
    </form>   
        <p style="margin-top: 15px;">Just a search results page</p>
        <?php if ($count == 0):?>
        <p>No matching listings found for:</p>
        <?php elseif ($count == 1):?> 
        <p>1 matching listing found for:</p>
        <?php
        elseif ($count > 1):?>
        <p><?= $count. ' matching listings found for:'?></p> 
        <?php endif;
        ?>   
        <?php if ( ! empty($_GET['district'])):?> 
        <p><strong>District: <?= $_GET['district']; ?></strong></p>
        <?php endif;

        if ( ! empty($_GET['area'])):?> 
        <p><strong>Area: <?= $_GET['area']; ?></strong></p>
        <?php endif;

        if ( ! empty($_GET['rooms'])):?> 
        <p><strong>Bedrooms: <?= $_GET['rooms']; ?></strong></p>
        <?php endif;

        if ( ! empty($_GET['baths'])):?> 
        <p><strong>Bathrooms: <?= $_GET['baths']; ?></strong></p>
        <?php endif;

        if ( ! empty($_GET['type'])):?> 
        <p><strong>Type: <?= $_GET['type']; ?></strong></p>
        <?php endif;  

        if ( ! empty($_GET['price_min'])):?> 
        <p><strong>Min Price: <?= $_GET['price_min']; ?></strong></p>
        <?php endif;
        
        if ( ! empty($_GET['price max'])):?> 
        <p><strong>Max Price: <?= $_GET['price_max']; ?></strong></p>
        <?php endif ?>         

        <div class ="container property">
        <div class ="row">
            <?php foreach ($search_results as $item): ?>
            <div class="col-md-4 listing-div card-body">  
                <a href="<?= site_url('listings/'.$item['slug'])?>">
                <img class="img-fluid" src=<?= HTTP_UPLOAD_MAIN.$item['image'];?> loading="lazy">
                </a>
                <div class="property-caption">
                    <?php
                    // add commas to numbers
                    $price = number_format($item['price']);
                    // get listing contract type
                    $type = $item['type'];
                    ?>
                    <h3 class="price">
                    K<?= $price;
                    // check contract type. if rent, show "per month symbol(/mo)"
                    if ($type == 'Rent'):?>
                    /mo 
                    <?php endif; ?>
                <h6><?= $item['bedrooms'] . 'Bds - ' . $item['bathrooms'] . 'Ba';?></h6>
                <a href="<?= site_url('listings/'.$item['slug'])?>"><p><?= $item['name']; ?></p></a>
                <h6><i class="fa fa-map-marker-alt"></i><?= $item['district'] . ', ' . $item['area']; ?></h6>
                <?php 
                if(isset($_SESSION['user_id'])) {
                $user_id = $_SESSION['user_id'];
                } else {
                $user_id = 0;    
                }
                if ($user_id != $item['user_id']):
                    if($user_id == 0):?>
                        <a href="<?= site_url('user/login')?>">
                    <?php else:?>    
                        <a href="<?= site_url('messages/compose/'.$item['user_id']); ?>">
                    <?php endif?>
                        <p>Message Seller</p></a>    
                <?php endif ?>  
                </div>  
            </div>
            <?php endforeach ?>
        </div>    
        </div>
    </div>

    <ul class="pagination justify-content-center" style="margin:20px 0">
        <?= $links ?>
    </ul>
<div id="footer" class="text-center">
          The Nation Advertising
     </div>
<script src="<?= site_url('public/js/jquery.min.js')?>"></script>
<script src="<?= site_url('public/js/popper.min.js')?>"></script>
<script src="<?= site_url('public/js/bootstrap.min.js')?>"></script>
<script src="<?= site_url('public/js/owl.carousel.min.js')?>"></script>
<script src="<?= site_url('public/js/myquery.js')?>"></script>

</body>
</html>
