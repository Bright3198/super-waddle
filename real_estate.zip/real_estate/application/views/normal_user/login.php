<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
        <link rel="stylesheet" href="<?php echo site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/style.css')?>">

</head>
<body>
	<!-- NAV -->
	<nav style="margin-bottom: 30px;" class="navbar navbar-expand-lg navbar-light bg-light">
		<a class="navbar-brand" href="<?= site_url(); ?>">The Nation Advertising</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span><i class="fa fa-bars"></i></span>
	  	</button>
	  	</div>
	</nav>    
    <div class="container">
        <?php echo form_open('auth/login');?>
        <div class="form-group">
        <?php echo validation_errors(); ?> 
            <fieldset disabled>
                <input type="text" id="disabledTextInput" class="form-control" placeholder="Login">
            </fieldset>        
            <input style="margin-top: 30px;" name="email" class="form-control" type="text" value="<?php echo set_value('email');?>" placeholder="Email"><br>
            <input name="password" class="form-control" type="password" placeholder="Password" required><br>
            <button class="btn btn-primary">Login</button>
            <a class="btn btn-info" href="<?php echo site_url('user/signup')?>">Signup</a>  
        </div>
        </form>
    </div>
<script src="<?php echo site_url('public/js/jquery.min.js')?>"></script>
<script src="<?php echo site_url('public/js/popper.min.js')?>"></script>
<script src="<?php echo site_url('public/js/bootstrap.min.js')?>"></script>
<script src="<?php echo site_url('public/js/owl.carousel.min.js')?>"></script>
<script src="<?php echo site_url('public/js/myquery.js')?>"></script>
</body>
</html>