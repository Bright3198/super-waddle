<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inbox</title>
        <link rel="stylesheet" href="<?php echo site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/style.css')?>">

</head>
<body>
  <!-- NAV -->
<nav style="margin-bottom: 30px;" class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?= site_url()?>">The Nation</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="<?= site_url()?>">Home</a>
      <?php
      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] <= 1):?>
      <a class="nav-item nav-link" href="<?= site_url('user/upload_listing')?>">Upload Listing</a>
      <?php
      endif;
      endif;
      ?> 
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Rent')?>">For Rent</a> 
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Sale')?>">For Sell</a> 
      <?php if (isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link active" href="<?= site_url('messages/inbox')?>">Messages <span class="sr-only">(current)</span></a>
      <a class="nav-item nav-link" href="<?= site_url('user/logout')?>">Logout</a>  
      <?php endif;
      if ( ! isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('user/signup')?>">Signup</a>  
      <a class="nav-item nav-link" href="<?= site_url('user/login')?>">Login</a>  
      <?php endif ?>          

    </div>
  </div>
</nav> 
<div class= "d-flex justify-content-center">
<div class="card text-left" style="width: 18rem;">
  <div class="card-header">
    <strong><em>Messages</em></strong>
  </div>
  <?php 
  // check if latest msg was sent by user
  $owner_id = $_SESSION['user_id']; 
  foreach ($latest_msg as $item):
  $read = $item['read_status']; 
  ?>
  <ul class="list-group list-group-flush">
  <a href="<?= site_url('messages/chat/' . $item['chat_id']); ?>">
  <p class="card-text"><strong><?= $item['chat_name']; ?></strong><br>
  <?php
  // if user is sender, show read status 
  if($owner_id == $item['sender_id']):
    if ($read == 0): // check if receiver opened message?>
    <i class="fa fa-check"></i>
    <?php else:?>
    <i class="fa fa-check-double"></i>
    <?php endif; ?>  
  <?php endif; ?>
  <?= $item['message']; ?>
  <small class="float-right"><?= $item['time_display']; ?></small></p>
  </a>
  </ul>
  <?php endforeach ;?>
</div>
</div>    

<div id="footer" class="text-center">
          The Nation Advertising
</div>
<script src="<?php echo site_url('public/js/jquery.min.js')?>"></script>
<script src="<?php echo site_url('public/js/popper.min.js')?>"></script>
<script src="<?php echo site_url('public/js/bootstrap.min.js')?>"></script>
<script src="<?php echo site_url('public/js/owl.carousel.min.js')?>"></script>
<script src="<?php echo site_url('public/js/myquery.js')?>"></script>

</body>
</html>