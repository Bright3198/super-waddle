<p>Chatting with <?php echo $user['name'];?></p>
<?php echo form_open('messages/store/'.$user['id']); ?>
<textarea name="message" placeholder="Type your msg here..."></textarea> 
<button type="submit">Send</button>   
</form>