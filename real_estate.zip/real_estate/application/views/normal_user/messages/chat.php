<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $user['name'] ?></title>
        <link rel="stylesheet" href="<?php echo site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/style.css')?>">

</head>
<body>
	<!---BASIC ASS NAV--->
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<a class="navbar-brand" href="#"><h3>The Nation Advertising</h3></a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span><i class="fa fa-bars"></i></span>
	  	</button>

	  	</div>
	</nav> 
<?php
if ( ! empty($_SESSION['user_id'])) { 
$owner_id = $_SESSION['user_id']; 
} else {
echo 'how tf you get here, Login fool!';
}   
?> 
<p>Chat with <?php echo $user['name'] ?></p>
<?php foreach ($chat as $item):?>
    <div style="height: 40px; background-color: #000">    
        <?php if ($owner_id == $item['sender_id']):?>
            <div>
            <p style="color: green; margin-bottom: 15px;"><?php echo $item['message']; ?></p>
            </div>
        <?php elseif ($owner_id == $item['receiver_id']):?>      
            <p style="color: blue"><?php echo $item['message']; ?></p>
    <?php endif ?>
    </div>
<?php endforeach; ?>    
<?php echo form_open('messages/store/'.$user['id']); ?>
<?php echo validation_errors(); ?>
<br>
<textarea name="message" placeholder="Type your msg here..."></textarea> 
<button type="submit">Send</button>   
</form>
<script src="<?php echo site_url('public/js/jquery.min.js')?>"></script>
<script src="<?php echo site_url('public/js/popper.min.js')?>"></script>
<script src="<?php echo site_url('public/js/bootstrap.min.js')?>"></script>
<script src="<?php echo site_url('public/js/owl.carousel.min.js')?>"></script>
<script src="<?php echo site_url('public/js/myquery.js')?>"></script>
</body>
</html>
