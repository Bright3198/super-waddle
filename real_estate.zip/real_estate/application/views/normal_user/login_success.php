Ohayo! Logged in!
<?php
$user_email = $_SESSION['user_email'];
$user_permissions = $_SESSION['user_permissions'];
?>
Click <a href="<?php echo site_url('user/logout')?>">here</a> to logout <br>
<p>Your email is <?php echo $user_email; ?></p><br>
<p>Your permission level is <?php echo $user_permissions; ?></p><br>
<?php if ($user_permissions == 0)
{
?>
   <a href="<?php echo site_url('admin/list_users');?>">List Users</a> 
<?php 
}
?>

<a href ="<?php echo site_url()?>">127.0.0.1</a>