<p><strong>Property Name: </strong><?php echo $listing_item['name']; ?></p><br>
<img style="height: 80px;" src=<?php print HTTP_UPLOAD_MAIN.$listing_item['image'];?>>
<h1>Map!!!</h1>
<p>Location: <?php echo $listing_item['district'];?>, <?php echo $listing_item['area'];?>
<?php 
if ($count == 0): 
  echo form_open('subscription/store'); ?> 
<p><button type="submit">Subscribe</button> to get notifications when new listings appear in this area</p>
<input type="hidden" name="district" value="<?php echo $listing_item['district'];?>">
<input type="hidden" name="area" value="<?php echo $listing_item['area'];?>">
</form>
<?php endif ?>
<?php
if ($count == 1): 
echo form_open('subscription/unsubscribe'); ?> 
<p><button type="submit">Unsubscribe</button> to stop receiving notifications when new listings appear in this area</p>
<input type="hidden" name="slug" value="<?php echo $listing_item['slug'];?>">
<input type="hidden" name="district" value="<?php echo $listing_item['district'];?>">
<input type="hidden" name="area" value="<?php echo $listing_item['area'];?>">
</form>
<?php endif ?>
<?php if ( ! empty($listing_item['lat'])):?>
<p>Coordinates available</p>    
<?php endif ?>
<iframe
  width="450"
  height="250"
  frameborder="0" style="border:0"
  src="https://www.google.com/maps/embed/v1/view?key=AIzaSyCc_Nv5D4IWwv9xlQ4TjCnK-YlqgNfcGIE&center=<?= $listing_item['lat'] . ',' . $listing_item['lng']?>&zoom=15" allowfullscreen>
</iframe>

