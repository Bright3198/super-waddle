<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Listing</title>
        <link rel="stylesheet" href="<?= site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/style.css')?>">

</head>
<body>
  <!-- NAV -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?= site_url()?>">The Nation</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="<?= site_url()?>">Home</a>
      <?php
      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] <= 1):?>
      <a class="nav-item nav-link" href="<?= site_url('user/upload_listing')?>">Upload Listing</a>
      <a class="nav-item nav-link" href="<?= site_url('user/listings')?>">My Listings</a>
      <?php
      endif;
      endif;

      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] == 0):?>
      <a class="nav-item nav-link" href="<?= site_url('admin')?>">Admin Panel</a>
      <?php
      endif;
      endif;
      ?>       
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Rent')?>">For Rent</a> 
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Sale')?>">For Sell</a> 
      <?php if (isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('messages/inbox')?>">Messages</a>   
      <a class="nav-item nav-link" href="<?= site_url('user/logout')?>">Logout</a>  
      <?php endif;
      if ( ! isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('user/signup')?>">Signup</a>  
      <a class="nav-item nav-link" href="<?= site_url('user/login')?>">Login</a>  
      <?php endif ?>          

    </div>
  </div>
</nav>    
    <div class="container">    
    <!-- Edit Listing Form -->  
    <form action="<?= site_url('listing/update/' . $listing['id']); ?>" method="post">

        <?= form_error('name'); ?>
        <p style="margin-top: 30px;">Name</p>
        <div class="mb-3">
        <input type="text" name="name" value="<?= $listing['name']?>" class="form-control" placeholder="Name">
        </div>

        <?= form_error('address'); ?>
        <p>Address</p>
        <div class="mb-3">
        <input type="text" name="address" value="<?= $listing['address']?>" class="form-control" placeholder="Address">
        </div>

        <?= form_error('description'); ?>
        <p>Description</p>
        <div class="mb-3">
        <textarea class="form-control" name="description"><?= $listing['description_edit']?></textarea><br>
        </div>

        <?= form_error('bedrooms'); ?>
        <p>Bedrooms:
        <select class="form-select" name="bedrooms">
            <option value="<?= $listing['bedrooms']?>"><?= $listing['bedrooms']?></option>     
            <?php for ($x = 1; $x <= 10; $x++):?>   
            <option value="<?= $x?>"><?= $x;?></option>
            <?php endfor ?>
        </select>
        </p>
        
        <?= form_error('bathroom'); ?>
        <p>Bathrooms:
        <select name="bathrooms">
            <option value="<?= $listing['bedrooms']?>"><?= $listing['bedrooms']?></option>    
            <?php for ($x = 1; $x <= 10; $x++):?>
            <option value="<?= $x?>"><?= $x?></option>
            <?php endfor ?>
        </select>    
        </p>
        
        <?= form_error('district'); ?>
        <p>District:
        <select name="district">
            <option value="<?= $listing['district']?>"><?= $listing['district']?></option> 
            <?php foreach ($districts as $item): ?>
            <option value="<?= $item['name']?>"><?= $item['name']?></option>
            <?php endforeach ?>
        </select><br>
        </p>
        
        <?= form_error('Area'); ?>
        <p>Area: 
        <select name="area">
            <option value="<?= $listing['area']?>"><?= $listing['area']?></option> 
            <?php foreach ($areas as $item): ?>
            <option value="<?= $item['name']?>"><?= $item['name']?></option>
            <?php endforeach ?>
        </select><br> 
        </p>
        
        <?= form_error('type'); ?>
        <p>Contract Type:
        <select name="type">
            <?php
            if ($listing['type'] == 'Rent'):
                $type = 'For Rent';
            elseif ($listing['type'] == 'Sale'): 
                $type = 'For Sell';
            ?>    
            <option value="<?= $listing['type']?>"><?= $type ?></option>
            <?php endif; ?>
            <option value="Rent">For Rent</p>
            <option value="Sale">For Sell</option>    
        </select>    
        </p>
        
        <?= form_error('price'); ?>
        <p>Price</p>
        <div class="mb-3">       
        <input type="text" class="form-control" name="price" value="<?= $listing['price'];?>" placeholder="Price">
        </div>        
        
        <p>Latitude</p>
        <div class="mb-3">       
        <input type="text" class="form-control" name="lat" value="<?= $listing['lat'];?>" placeholder="Latitude">
        </div>
        
        <p>Longitude</p>
        <div class="mb-3">
        <input type="text" class="form-control" name="lng" value="<?= $listing['lng']; ?>" placeholder="Longitude">
        </div>

        <button type="submit" class="btn btn-primary">Save</submit></button>
        <a class="btn btn-danger" href="<?= site_url('user/listings'); ?>">Back</a>
    </form>
    </div>
        <script src="<?= site_url('public/js/jquery.min.js')?>"></script>
        <script src="<?= site_url('public/js/popper.min.js')?>"></script>
        <script src="<?= site_url('public/js/bootstrap.min.js')?>"></script>
        <script src="<?= site_url('public/js/owl.carousel.min.js')?>"></script>
        <script src="<?= site_url('public/js/myquery.js')?>"></script>

</body>
</html>