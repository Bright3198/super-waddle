<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $listing['name']; ?></title>
        <link rel="stylesheet" href="<?= site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/style.css')?>">

</head>
<body>
  <!-- NAV -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?= site_url()?>">The Nation</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="<?= site_url()?>">Home</a>
      <?php
      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] <= 1):?>
      <a class="nav-item nav-link" href="<?= site_url('user/upload_listing')?>">Upload Listing</a>
      <a class="nav-item nav-link" href="<?= site_url('user/listings')?>">My Listings</a>
      <?php
      endif;
      endif;

      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] == 0):?>
      <a class="nav-item nav-link" href="<?= site_url('admin')?>">Admin Panel</a>
      <?php
      endif;
      endif;
      ?>       
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Rent')?>">For Rent</a> 
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Sale')?>">For Sell</a> 
      <?php if (isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('messages/inbox')?>">Messages</a>   
      <a class="nav-item nav-link" href="<?= site_url('user/logout')?>">Logout</a>  
      <?php endif;
      if ( ! isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('user/signup')?>">Signup</a>  
      <a class="nav-item nav-link" href="<?= site_url('user/login')?>">Login</a>  
      <?php endif ?>          

    </div>
  </div>
</nav>   
<body>
    <div class="container-fluid">
        <div class="row flex justify-content-center">
            <div class="col-md-6">
                <div class="row">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 ">
                                <!-- title and main property image -->
                                <figure class="proppage">
                                    <h4 class="figtitle"><?= $listing['name']; ?></h4>
                                    <img style="height: 400px;" class="img-fluid" src="<?= HTTP_UPLOAD_MAIN . $listing['image']; ?>" alt="Main image">
                                </figure>
                            </div>

                            <!-- more images -->
                            <div class="col-md-12">
                                <h4 class="more-title">More Images</h4>
                            </div>
                            <div class="col-md-4">
                                <figure class="more-tab">
                                    <img class="image-fluid" src="imgs/hs (2).jpg" alt="more imgs">
                                </figure>
                            </div>

                            <!-- property details -->
                            <div class="col-md-12">
                                <h4 class="more-title">Details</h4>
                            </div>
                            <div class="col-md-12">
                                <ul class="prop-meta">
                                    <li><a href=""><span class="fa fa-map-marker-alt"></span><?= $listing['district'] . ', ' . $listing['area']; ?></a></li>
                                    <li><a href=""><span class="fa fa-globe"></span><?= $listing['address']; ?></a></li>
                                    <?php 
                                    // comma separator
                                    $price = number_format($listing['price']);
                                    $type = $listing['type'];
                                    ?>
                                    <li><a href=""><span class="fas fa-comments-dollar"></span>K <?= $price; 
                                    // check contract type. if rent, out "per month symbol(/mo)"
                                    if ($type == 'Rent'):?>
                                        /mo 
                                    <?php endif; ?>
                                    </a></li>
                                    <li><a href=""><span class="fa fa-phone"></span>+265 999 15 44 32</a></li>
                                    <?php 
                                    // check if user has logged in
                                    if(isset($_SESSION['user_id'])) {
                                    $user_id = $_SESSION['user_id'];
                                    } else {
                                    $user_id = 0;    
                                    }
                                    if ($user_id != $listing['user_id']):
                                        // if not logged in, redirect to login
                                        if($user_id == 0):?>
                                            <a href="<?php echo site_url('user/login')?>">
                                        <?php 
                                        else:?>    
                                            <li><a href="<?php echo site_url('messages/compose/'.$listing['user_id']); ?>">
                                        <?php endif?>
                                            <span class="fas fa-comment-dots"></span>Chat with seller</a></li>    
                                    <?php endif ?>                                    
                                    <?php 
                                    if ($count == 0): 
                                        echo form_open('subscription/store'); ?>
                                    <li><a><button type="submit" class="subscribe-btn"><span class="fa fa-bell fa-spin"></span>Subscribe</button></a> to get notifications when new listings appear in this area</li>
                                    <input type="hidden" name="slug" value="<?= $listing['slug'];?>">
                                    <input type="hidden" name="district" value="<?= $listing['district'];?>">
                                    <input type="hidden" name="area" value="<?= $listing['area'];?>">
                                    </form>
                                    <?php endif;  
                                    if ($count == 1): 
                                    echo form_open('subscription/unsubscribe'); ?> 
                                    <li><a><button type="submit" class="subscribe-btn">Unsubscribe</button> to stop receiving notifications when new listings appear in this area</li></a>
                                    <?php endif; ?>                                
                                   
                                    <?php if ( ! empty($listing_item['lat'])):?>
                                    <p>Coordinates available</p>    
                                    <?php endif ?>
                                    <iframe
                                    width="450"
                                    height="250"
                                    frameborder="0" style="border:0"
                                    src="https://www.google.com/maps/embed/v1/view?key=AIzaSyCc_Nv5D4IWwv9xlQ4TjCnK-YlqgNfcGIE&center=<?= $listing['lat'] . ',' . $listing['lng']?>&zoom=15" allowfullscreen>
                                    </iframe>                                    
                                    
                                    <p>Address ???</p>
                                    <?php 
                                    $address = str_replace(' ', '+', $listing['address']); ?>
                                    <iframe
                                    width="450"
                                    height="250"
                                    frameborder="0" style="border:0"
                                    src="https://www.google.com/maps/embed/v1/place?key=AIzaSyCc_Nv5D4IWwv9xlQ4TjCnK-YlqgNfcGIE&q=<?= $address; ?>&zoom=15" allowfullscreen>
                                    </iframe>                                      
                                </ul>
                            </div>
                            <!-- property details end -->
                        </div>
                    </div>
                </div>
                <!--_
                <div class="row ">
                    <div class="col-md-12 share">
                        <ul class="property-share">
                            <li><a href=""><button class="fb-btn"><span class="fab fa-facebook"></span>Share on facebook</button></a></li>
                            <li><a href=""><button class="twitter-btn"><span class="fab fa-twitter"></span>Share on twitter</button></a></li>
                            <li><a href=""><button class="whatsapp-btn"><span class="fab fa-whatsapp"></span>Share on whatsapp</button></a></li>
                        </ul>
                    </div>
                </div>
                --->
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12 more-heading">
                        <h6 class="more-from">More From Area</h6>
                    </div>
                    <div class="col-md-12">
                        <figure class="more-from-area">
                            <a href="property.html"><img class="img-fluid" src="imgs/hs (6).jpg" alt=""></a>
                        </figure>
                        <h6 class="more-from-title">Another fine house</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
        <footer>
            <div class="container">
                <div class="row inhouse-footer">
                    <div class="col-md-4 foot-seg">
                        <img class="img-fluid" src="imgs/logo.png">
                        <p>bla bla bla moto</p>
                        <ul class="social-link-list">
                            <li><a href=""><button class="social-facebook"><i class="fab fa-facebook"></i></button></a></li>
                            <li><a href=""><button class="social-twitter"><i class="fab fa-twitter"></i></button></a></li>
                            <li><a href=""><button class="social-instagram"><i class="fab fa-instagram"></i></button></a></li>
                            <li><a href=""><button class="social-google"><i class="fab fa-google"></i></button></a></li>
                        </ul>
                    </div>
                    <div class="col-md-4 foot-seg">
                        <h4>Quick Links</h4>
                        <ul class="quick-links">
                            <li><a href=""><i class="fa fa-angle-double-right"></i>Home</a></li>
                            <li><a href=""><i class="fa fa-angle-double-right"></i>Apartments</a></li>
                            <li><a href=""><i class="fa fa-angle-double-right"></i>Rentals</a></li>
                            <li><a href=""><i class="fa fa-angle-double-right"></i>About</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4 foot-seg">
                        <h4>Contact</h4>
                        <ul class="address">
                            <li><a href=""><i class="fa fa-map-marker-alt"></i> Blantyre</a></li>
                            <li><a href=""><i class="fa fa-phone"></i>0999 9999 999</a></li>
                            <li><a href=""><i class="fa fa-envelope"></i>info@ngalurealtor.com</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>

        <script src="<?= site_url('public/js/jquery.min.js')?>"></script>
        <script src="<?= site_url('public/js/popper.min.js')?>"></script>
        <script src="<?= site_url('public/js/bootstrap.min.js')?>"></script>
        <script src="<?= site_url('public/js/owl.carousel.min.js')?>"></script>
        <script src="<?= site_url('public/js/myquery.js')?>"></script>

</body>
</html>