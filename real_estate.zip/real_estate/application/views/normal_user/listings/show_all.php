<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profile</title>
        <link rel="stylesheet" href="<?php echo site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/style.css')?>">

</head>
<body>
	<!---BASIC ASS NAV--->
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<a class="navbar-brand" href="#"><h3>The Nation Advertising</h3></a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span><i class="fa fa-bars"></i></span>
	  	</button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    	<ul class="navbar-nav mr-auto">
	        	<li class="nav-item active">
	        		<a class="nav-link" href="<?= site_url()?>">Home </a>
	      		</li>
	      		<li class="nav-item">
	        		<a class="nav-link" href="#">RENT</a>
	      		</li>
	      		<li class="nav-item">
	        		<a class="nav-link" href="#">BUY</a>
	      		</li>
	      		<li class="nav-item">
	        		<a class="nav-link" href="#">LEASE</a>
	      		</li>
	      		<li class="nav-item">
	        		<a class="nav-link" href="#">CONTACT US</a>
	      		</li>
                <?php if (isset($_SESSION['user_email'])):?>     
	      		<li class="nav-item">
	        		<a class="nav-link" href="<?= site_url('user/profile')?>"><i class="fa fa-user"></i><?php echo $user['name']?></a>
	      		</li>
	      		<li class="nav-item">
	        		<a class="nav-link" href="<?= site_url('user/logout')?>">LOGOUT</a>
	      		</li>                  
                <?php endif; ?>                
	   		</ul>
	  	</div>
	</nav>
<p>Guess this works</p>
<p>Search Test</p>
<form action="<?php echo site_url('search/index');?>" method="get">
    <label>District:</label>
    <select name="district">
        <option value="0">Any</option>
        <?php foreach ($districts as $item): ?>
            <option value="<?php echo $item['name']; ?>"><?php echo $item['name']; ?></option>
        <?php endforeach?>    
    </select>

    <label>Area:</label>
    <select name="area">
        <option value="0">Any</option>
        <?php foreach ($areas as $item): ?>
            <option value="<?php echo $item['name']; ?>"><?php echo $item['name']; ?></option>
        <?php endforeach?>        
    </select>

    <label>Bathrooms:</label>
    <select name="baths">
        <option value="0">Any</option>
        <?php for ($x = 1; $x <= 10; $x++):?>
            <option value="<?php echo $x?>"><?php echo $x;?></option>
        <?php endfor ?>
    </select>

    <label>Bedrooms:</label>
    <select name="rooms">
        <option value="0">Any</option>
        <?php for ($x = 1; $x <= 10; $x++):?>
            <option value="<?php echo $x?>"><?php echo $x?></option>
        <?php endfor ?>        
    </select>
    
    <label>Type:</label>
    <select name="type">
        <option value="0">Any</option>
        <option value="Rent">Rent</option>
        <option value="Sale">Sale</option>    
    </select>

    <label>Min Price:</label>
    <input style="width: 120px;" type="text" name="price_min">       

    <label>Max Price:</label>
    <input style="width: 120px;" type="text" name="price_max">     
    
    <button style="background-color: #000; color: #fff; border-radius: 15px;" type="submit">Blow!💥</button>
</form>
<?php foreach ($listings as $item): ?>
<a href="<?php echo site_url('listings/'.$item['slug'])?>"><p><?php echo $item['name'];?></p></a><br>
<img style="height: 80px;" src=<?php print HTTP_UPLOAD_MAIN.$item['image'];?>>
<a href="<?php echo site_url('messages/compose/'.$item['user_id']); ?>"><p>Message Seller</p></a>
<?php endforeach ?>    

<script src="<?php echo site_url('public/js/jquery.min.js')?>"></script>
<script src="<?php echo site_url('public/js/popper.min.js')?>"></script>
<script src="<?php echo site_url('public/js/bootstrap.min.js')?>"></script>
<script src="<?php echo site_url('public/js/owl.carousel.min.js')?>"></script>
<script src="<?php echo site_url('public/js/myquery.js')?>"></script>
</body>
</html>