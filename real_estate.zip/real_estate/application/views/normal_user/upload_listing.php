<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Upload Listing</title>
        <link rel="stylesheet" href="<?= site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?= site_url('public/css/style.css')?>">

</head>
<body>
<!-- NAV -->
<nav style="margin-bottom: 30px;" class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?= site_url()?>">The Nation</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="<?= site_url()?>">Home</a>
      <?php
      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] <= 1):?>
      <a class="nav-item nav-link active" href="<?= site_url('user/upload_listing')?>">Upload Listing</a>
      <a class="nav-item nav-link" href="<?= site_url('user/listings')?>">My Listings</a>
      <?php
      endif;
      endif;

      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] == 0):?>
      <a class="nav-item nav-link" href="<?= site_url('admin')?>">Admin Panel</a>
      <?php
      endif;
      endif;
      ?>       
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Rent')?>">For Rent</a> 
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Sale')?>">For Sell</a> 
      <?php if (isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('messages/inbox')?>">Messages</a>   
      <a class="nav-item nav-link" href="<?= site_url('user/logout')?>">Logout</a>  
      <?php endif;
      if ( ! isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('user/signup')?>">Signup</a>  
      <a class="nav-item nav-link" href="<?= site_url('user/login')?>">Login</a>  
      <?php endif ?>          

    </div>
  </div>
</nav>     
    <div class="container">    
    <!-- Upload Listing Form -->  
    <form action="<?= site_url('upload/listing')?>" method="post" multipart="" enctype="multipart/form-data">
        <!-- Check if an error was sent -->
        <?php if (isset($error)): ?>
        <div class="alert alert-danger">There were some issues processing your form, scroll down to see and fix them</div>
        <?php endif; ?>
        <p>Name</p> 
        <?= form_error('name'); ?>
        <div class="mb-3"> 
        <input type="text" style="margin-top: 30px;" name="name" value="<?= set_value('name'); ?>" class="form-control" placeholder="Name">
        </div>

        <p>Address</p>
        <?= form_error('address'); ?>
        <div class="mb-3">
        <input type="text" name="address" value="<?= set_value('address'); ?>" class="form-control" placeholder="Address">
        </div>

        <p>Description</p>
        <?= form_error('description'); ?>
        <div class="mb-3">
        <textarea class="form-control" name="description"><?= set_value('description'); ?></textarea><br>
        </div>

        <p>Bedrooms</p>
        <?= form_error('bedrooms'); ?>
        <select class="form-select" name="bedrooms">
        <?php for ($x = 1; $x <= 10; $x++):?>
        <option value="<?= $x?>"><?= $x;?></option>
        <?php endfor ?>
        </select>

        <p>Bathrooms</p>
        <?= form_error('bathrooms'); ?>
        <select name="bathrooms">
        <?php for ($x = 1; $x <= 10; $x++):?>
        <option value="<?= $x?>"><?= $x?></option>
        <?php endfor ?>
        </select>    

        <p>District</p> 
        <?= form_error('district'); ?>
        <select name="district">
        <?php foreach ($districts as $item): ?>
        <option value="<?= $item['name']?>"><?= $item['name']?></option>
        <?php endforeach ?>
        </select><br>

        <p>Area</p> 
        <?= form_error('area'); ?>
        <select name="area">
        <?php foreach ($areas as $item): ?>
        <option value="<?= $item['name']?>"><?= $item['name']?></option>
        <?php endforeach ?>
        </select><br> 

        <?= form_error('type'); ?>
        <p>Contract Type:
          <select name="type">
            <option value="Rent">For Rent</p>
            <option value="Sale">For Sell</option>    
        </select>    
        </p>
        
        <?= form_error('price'); ?>
        <p>Price or Rent per Month</p>
        <div class="mb-3">       
        <input type="text" class="form-control" name="price" value="<?= set_value('price'); ?>" placeholder="Price: No commas, e.g. 1000000, if for rent simply put the rent per month e.g. 100000">
        </div>           

        <div class="mb-3">       
        <input type="text" class="form-control" name="lat" value="<?= set_value('lat'); ?>" placeholder="Latitude">
        </div>

        <div class="mb-3">
        <input type="text" class="form-control" name="lng" value="<?= set_value('lng'); ?>" placeholder="Longitude">
        </div>

        <div class="mb-3"> 
        <input type="file" name="image" accept="image/*" required>
        </div>

        <button type="submit" class="btn btn-primary">Upload</submit></button><br>
        <a href=<?= site_url()?>>Lazy</a>
    </form>
    </div>
        <script src="<?= site_url('public/js/jquery.min.js')?>"></script>
        <script src="<?= site_url('public/js/popper.min.js')?>"></script>
        <script src="<?= site_url('public/js/bootstrap.min.js')?>"></script>
        <script src="<?= site_url('public/js/owl.carousel.min.js')?>"></script>
        <script src="<?= site_url('public/js/myquery.js')?>"></script>

</body>
</html>