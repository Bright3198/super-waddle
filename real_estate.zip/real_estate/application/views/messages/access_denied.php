<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Access Denied</title>
        <link rel="stylesheet" href="<?php echo site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/style.css')?>">

</head>
<body>
	<!---BASIC ASS NAV--->
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<a class="navbar-brand" href="#"><h3>The Nation Advertising</h3></a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span><i class="fa fa-bars"></i></span>
	  	</button>

	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
	  	</div>
	</nav>    
    <div class="container py-5">
          <div class="row">
               <div class="col-md-2 text-center">
                    <p><i class="fa fa-exclamation-triangle fa-5x"></i><br/>Status Code: 403</p>
               </div>
               <div class="col-md-10">
                    <h3>ACCESS DENIED</h3>
                    <p>Sorry, you do not have enough permissions to view this page.<br/>Please go back to the previous page to continue browsing.</p>
                    <a class="btn btn-danger" href="<?php echo site_url();?>">Go Back</a>
                    <?php echo $_SESSION['user_permissions'];?>
                    <?php echo $_SESSION['user_email'];?>
               </div>
          </div>
     </div>

     <div id="footer" class="text-center">
          The Nation Advertising
     </div>
<script src="<?php echo site_url('public/js/jquery.min.js')?>"></script>
<script src="<?php echo site_url('public/js/popper.min.js')?>"></script>
<script src="<?php echo site_url('public/js/bootstrap.min.js')?>"></script>
<script src="<?php echo site_url('public/js/owl.carousel.min.js')?>"></script>
<script src="<?php echo site_url('public/js/myquery.js')?>"></script>

</body>
</html>