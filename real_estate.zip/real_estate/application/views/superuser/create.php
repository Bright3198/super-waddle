<title>Create Admin</title>
<?php echo form_open('auth/create_superuser')?>
<input name="name" type="text" placeholder="Name"><br>
<input name="email" type="text" placeholder="Email"><br>
<input name="password" type="text" placeholder="Password"><br>
<button>Create!</button>
</form>