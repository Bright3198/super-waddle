<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Delete Listing</title>
        <link rel="stylesheet" href="<?php echo site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/style.css')?>">

</head>
<body>
  <!-- NAV -->
  <nav style="margin-bottom: 30px;" class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?= site_url()?>">The Nation</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="<?= site_url()?>">Home</a>
      <?php
      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] <= 1):?>
      <a class="nav-item nav-link" href="<?= site_url('user/upload_listing')?>">Upload Listing</a>
      <a class="nav-item nav-link" href="<?= site_url('user/listings')?>">My Listings</a>
      <?php
      endif;
      endif;

      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] == 0):?>
      <a class="nav-item nav-link active" href="<?= site_url('admin')?>">Admin Panel</a>
      <?php
      endif;
      endif;
      ?>       
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Rent')?>">For Rent</a> 
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Sale')?>">For Sell</a> 
      <?php if (isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('messages/inbox')?>">Messages</a>   
      <a class="nav-item nav-link" href="<?= site_url('user/logout')?>">Logout</a>  
      <?php endif;
      if ( ! isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('user/signup')?>">Signup</a>  
      <a class="nav-item nav-link" href="<?= site_url('user/login')?>">Login</a>  
      <?php endif ?>          

	  </div>
  </div>
</nav> 

	<div class="container">
        <div class="d-flex justify-content-center">    
            <div class="card" style="width: 36rem;">
                <div class="card-header">
                    <strong>Confirm District Deletion?</strong>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>District:</strong> <?= $district['name']; ?></li>
                </ul>
                <div class="card-body">
                <form action="<?php echo site_url('district/purge'); ?>" method="post">
					<input name="id" type="hidden" value="<?= $district['id']?>">    
                    <button type="submit" class="btn btn-primary">Delete</submit></button>
                    <a class="btn btn-danger" href="<?= site_url('admin/list_districts'); ?>">Back</a>    
                </form>                        
                </div>    
            </div>  
      </div>    
    </div>

<script src="<?= site_url('public/js/jquery.min.js')?>"></script>
<script src="<?= site_url('public/js/popper.min.js')?>"></script>
<script src="<?= site_url('public/js/bootstrap.min.js')?>"></script>
<script src="<?= site_url('public/js/owl.carousel.min.js')?>"></script>
<script src="<?= site_url('public/js/myquery.js')?>"></script>

</body>
</html>