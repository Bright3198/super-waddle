<title>Mulitpiclity Test</title>
<?= form_open_multipart('upload/listing_beta');?>
<input type="file" accept="image/*" name="image_file[]" multiple="multiple">
<button type="submit">Upload</button>
<upload>
</form>