<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Panel</title>
        <link rel="stylesheet" href="<?php echo site_url('public/css/bootstrap.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/fa/css/all.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.carousel.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/owl.theme.default.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/anime/animate.min.css')?>">
        <link rel="stylesheet" href="<?php echo site_url('public/css/style.css')?>">

</head>
<body>
<!-- NAV -->
<nav style="margin-bottom: 30px;" class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?= site_url()?>">The Nation</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="<?= site_url()?>">Home</a>
      <?php
      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] <= 1):?>
      <a class="nav-item nav-link" href="<?= site_url('user/upload_listing')?>">Upload Listing</a>
      <a class="nav-item nav-link" href="<?= site_url('user/listings')?>">My Listings</a>
      <?php
      endif;
      endif;

      if (isset ($_SESSION['user_id'])):
        if ($_SESSION['user_permissions'] == 0):?>
      <a class="nav-item nav-link active" href="<?= site_url('admin')?>">Admin Panel</a>
      <?php
      endif;
      endif;
      ?>       
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Rent')?>">For Rent</a> 
      <a class="nav-item nav-link" href="<?= site_url('search/index?type=Sale')?>">For Sell</a> 
      <?php if (isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('messages/inbox')?>">Messages</a>   
      <a class="nav-item nav-link" href="<?= site_url('user/logout')?>">Logout</a>  
      <?php endif;
      if ( ! isset($_SESSION['user_email'])):?>
      <a class="nav-item nav-link" href="<?= site_url('user/signup')?>">Signup</a>  
      <a class="nav-item nav-link" href="<?= site_url('user/login')?>">Login</a>  
      <?php endif ?>          

    </div>
  </div>
</nav> 
    
    <body>
    <div class="container">   
    <div class="card-columns">
    <div class="card">
        <div class="card-body">
        <h5 class="card-title"><strong><i class="fa fa-hourglass-half"></i>The past 7 days</strong></h5>
        <p class="card-text">Users Registered: <?= $users_registered_lw; ?></p>
        <p class="card-text">Listings Posted: <?= $listings_posted_lw; ?></p>
        <?php if ($listings_posted_lw <= 10):?>
            <p class="card-text text-info">It's not looking too good</p>    
        <?php endif; ?>    
        </div>
    </div>
    <div class="card">
        <div class="card-body">
        <h5 class="card-title"><strong><i class="fa fa-calendar-alt"></i>The past 30 days</strong></h5>
        <p class="card-text">Users Registered: <?= $users_registered_mo; ?></p>
        <p class="card-text">Listings Posted: <?= $listings_posted_mo; ?></p>
        <?php if ($listings_posted_mo <= 40):?>
            <p class="card-text text-info">It's not looking too good</p>    
        <?php endif; ?>    
        </div>
    </div>
    <div class="card">
        <div class="card-body">
        <h5 class="card-title"><strong><i class="fa fa-map-marker-alt"></i>Add locations</strong></h5>
        <a class="btn btn-primary" href="<?= site_url('admin/create_district'); ?>">New district</a>
        <a class="btn btn-info" href="<?= site_url('admin/create_area'); ?>">New area</a>        
        </div>
    </div>
    <div class="card text-center">
        <div class="card-body">
        <h5 class="card-title"><strong><i class="fa fa-cogs"></i><i class="fa fa-map-marker-alt"></i>Manage Locations</strong></h5>
        <p class="card-text">Update and remove</p>
        <a class="btn btn-primary" href="<?= site_url('admin/list_districts'); ?>">Districts</a>
        <a class="btn btn-info" href="<?= site_url('admin/list_areas'); ?>">Areas</a>    
        </div>
    </div>  
    <div class="card mb-3">
        <a href="<?= site_url('report'); ?>">
        <img class="card-img-top" src="<?= BASE_URL . 'images/detailed_report.gif'; ?>" alt="Graph">  
        <div class="card-body">
            <h5 class="card-title"><i class="fa fa-chart-line"></i>View detailed reports</h5>
        </div>    
        </a>
    </div>
    <div class="card text-center">
        <div class="card-body">
        <h5 class="card-title"><strong><i class="fa fa-users"></i>Manage Users</strong></h5>
        <p class="card-text">Permissions and the like</p>
        <a class="btn btn-primary" href="<?= site_url('admin/list_users'); ?>">Click here</a>    
        </div>
    </div>
    <div class="card">
        <a href="<?= site_url('admin/subscribers'); ?>"><div class="card-body">
        <h5 class="card-title"><strong><i class=" fa fa-envelope"></i>Subscriptions</strong></h5>
        <?php foreach ($subscriptions_per_district as $item): ?>
          <button type="button" class="btn btn-info">
            <?= $item['district']; ?> <span class="badge badge-light"><?= $item['email_num']; ?></span>
          </button> 
        <?php endforeach; ?>
        </div>
        </a>
    </div>
    </div>
    </div>

    <div id="footer" class="text-center">
              The Nation Advertising
    </div>
<script src="<?php echo site_url('public/js/jquery.min.js')?>"></script>
<script src="<?php echo site_url('public/js/popper.min.js')?>"></script>
<script src="<?php echo site_url('public/js/bootstrap.min.js')?>"></script>
<script src="<?php echo site_url('public/js/owl.carousel.min.js')?>"></script>
<script src="<?php echo site_url('public/js/myquery.js')?>"></script>

</body>
</html>