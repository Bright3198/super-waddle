<?php
class User_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }

        public function get_users()
        {   
            $email = $_SESSION['user_email'];
            $query = $this->db->select('id, name, email, permissions')
                    ->where('email !=', $email)
                    ->order_by('created_at', 'DESC')
                    ->get('users');
            return $query->result_array();    
        }

        public function get_user($id)
        {   
            $query = $this->db->select('id, name, email, permissions, updated_by')
                    ->where('id', $id)
                    ->get('users');
            return $query->row_array();    
        }      

        public function update_user_permissions($id, $permissions)
        {   
            $admin = $_SESSION['user_email'];    
            $data = [
                'permissions' => $permissions,
                'updated_by' => $admin,
                'updated_at' => date("Y:m:d h:i:s"),
            ];    

            $query = $this->db->where('id', $id)
                    ->update('users', $data);
            return $query;  
        }        
        
}        