<?php
class Area_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }

        public function create()
        {
            $name = $this->input->post('name');
            $district = $this->input->post('district');
            $time = date("Y-m-d H:i:s");
            $data = [
            'name' => $name,
            'district' => $district,    
            'created_at' => $time,
            ]; 

            return $this->db->insert('areas', $data);
        }     
        
        public function get()
        {   
            $query = $this->db->select('id, name, district')
                    ->get('areas');
            return $query->result_array();    
        }   

        public function get_area($id)
        {   
            $query = $this->db->select('id, name, district')
                    ->where('id', $id)
                    ->get('areas');
            return $query->row_array();    
        }             

        public function update($id)
        {
			$name = $this->input->post('name');
			$district = $this->input->post('district');
			$time = date("Y-m-d H:i:s");
			$data = [
			'name' => $name,        
			'updated_at' => $time,
			'district' => $district,
			];

			$query = $this->db->where('id', $id);
			return $this->db->update('areas', $data);                 
        }

		public function delete()
        {   
            $id = $this->input->post('id');
            $query= $this->db->delete('areas', array('id' => $id));
            return $query;
        }


}        