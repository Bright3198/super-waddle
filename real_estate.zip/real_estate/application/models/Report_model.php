<?php
class Report_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }

        public function users_registered($days)
        {   
            $query = $this->db->select('created_at')
                                ->where('created_at >= DATE_SUB(CURDATE(), INTERVAL '. $days. ' DAY)')
                                ->get('users');
            $count = count($query->result());
            return $count; 
        }  

        public function listings_posted($days)
        {   
            $query = $this->db->select('created_at')
                                ->where('created_at >= DATE_SUB(CURDATE(), INTERVAL '. $days. ' DAY)')
                                ->get('listings');
            $count = count($query->result());
            return $count; 
        }     

        public function listing_clicks($district)
        {
            $query = $this->db->select('name, slug, click_count, district, area')
                                ->where('district', $district)
                                ->limit(5)
                                ->order_by('click_count', 'DESC')
                                ->get('listings');
            return $query->result_array();                    
        }

        public function month_report($mo = FALSE)
        {
            if ($mo = FALSE)
            {
                $query = $this->db->select('created_at')
                        ->like('created_at', '2021-'.$mo. ',' . 'after')
                        ->get('listings');
                $count = count($query->result());
                return $count;        
            }

            $query = $this->db->select('created_at')
                    ->like('created_at', '2021-'.$mo. ',' . 'after')
                    ->get('listings');
            $count = count($query->result());
            return $count;        
        }

        public function listings_per_district()
        {
            $query = $this->db->select('district, COUNT(name) AS posts_num')
                    ->group_by('district')
                    ->get('listings');
            return $query->result_array();        
        }

        public function subscriptions_per_district()
        {
            $query = $this->db->select('district, COUNT(user_email) AS email_num')
                    ->group_by('district')
                    ->get('subscriptions');
            return $query->result_array();        
        }

}        