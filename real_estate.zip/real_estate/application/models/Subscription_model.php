<?php
class Subscription_model extends CI_Model {

    public function get()
    {
        $query = $this->db->select('user_email, district, area, created_at')
                        ->get('subscriptions');
        return $query->result_array();                
    }
    
    public function create()
    {   
        $email = $_SESSION['user_email'];
        $area = $this->input->post('area');
        $district = $this->input->post('district');
        $time = date("Y-m-d H:i:s");

        $data = [
        'user_email' => $email,    
        'district' => $district,
        'area' => $area,
        'created_at' => $time,    
        ];

        return $this->db->insert('subscriptions', $data);
    }

    public function soft_delete()
    {   
        
        $email = $_SESSION['user_email'];
        $district = $this->input->post('district');
        $area = $this->input->post('area');
        $time = date("Y-m-d H:i:s");

        $data = [
            'status' => 0,
            'updated_at' => $time    
        ];

        $query = $this->db->update('subscriptions', $data, array('user_email' => $email, 'area' => $area, 'district' => $district));
    }

    public function check_if_exists($email, $area, $district)
    {
        if ($email === NULL)
        {
            $count = 0;
            return $count;
        } 
        else 
        {
            $query = $this->db->select('user_email, district, area')
                            ->where('user_email', $email)
                            ->where('area', $area)
                            ->where('district', $district)
                            ->get('subscriptions');
            $count = count($query->result());
            return($count);
        }                     
    }

    public function get_listing()
    {   
        $id = $_SESSION['user_id'];
        $area = $this->input->post('area');
        $district = $this->input->post('district');

        $query = $this->db->select('area, district, slug, name, user_id')
                        ->limit(1)
                        ->order_by('created_at', 'DESC')
                        ->where('user_id', $id)
                        ->get('listings');
        return $query->row_array();        
    }

    public function get_subscribers()
    {   
        $email = $_SESSION['user_email'];
        $area = $this->input->post('area');
        $district = $this->input->post('district');

        $query = $this->db->select('user_email')
                        ->where('area', $area)
                        ->where('district', $district)
                        ->where('user_email !=', $email)
                        ->where('status', 1)
                        ->get('subscriptions');
        return $query->result_array(); 
    }

}    