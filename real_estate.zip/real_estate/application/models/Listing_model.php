<?php
class Listing_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }      

        public function create($image)
        {
            $name = $this->input->post('name');
            $user_id = $_SESSION['user_id'];
            $address = $this->input->post('address');
            $district = $this->input->post('district');
            $area = $this->input->post('area');
            $desc = $this->input->post('description');
            $bedrooms = $this->input->post('bedrooms');
            $bathrooms = $this->input->post('bathrooms');
            $price = $this->input->post('price');
            $lat = $this->input->post('lat');
            $lng = $this->input->post('lng');
            $random_num = random_string('basic', 6);
            $arr_replace = array("&quot;");
            $arr_needle = array('"');
            $string_replaced_desc = str_replace($arr_needle, $arr_replace, $desc); 
            $desc_nl2br = $this->typography->nl2br_except_pre($string_replaced_desc);
            $slug = url_title($name." ".$random_num, 'dash', TRUE);
            $time = date("Y-m-d H:i:s");

            $data = array(
                'name' => $name,
                'user_id' => $user_id,
                'address' => $address,
                'district' => $district,
                'area' => $area,
                'description' => $desc_nl2br,
                'description_edit' => $desc,
                'bedrooms' => $bedrooms,
                'bathrooms' => $bathrooms,
                'price' => $price,
                'lat' => $lat,
                'lng' => $lng,
                'slug' => $slug,
                'image' => $image,
                'created_at' => $time,
            );

            return $this->db->insert('listings', $data);
        }

        public function store_images($image = array())
        {   
            $data = array();
            $image[] = $image;
            $image_count = count($image);
            for($i = 0; $i<$image_count; $i++)
            {
               $arr[] = array(
                   'created_at' => date("Y-m-d H:i:s"),
                   'image' => $image['image_file'][$i]
                );
                   array_push($data, $arr);
            }    
            
            var_dump($image);
            return $this->db->insert_batch('image_gallery', $data);          
        }

        public function chaos($image_info = array())
        {
            return $this->db->insert_batch('image_gallery', $image_info);
        }        

        public function update($id)
        {
            $name = $this->input->post('name');
            $address = $this->input->post('address');
            $district = $this->input->post('district');
            $area = $this->input->post('area');
            $desc = $this->input->post('description');
            $bedrooms = $this->input->post('bedrooms');
            $bathrooms = $this->input->post('bathrooms');
            $price = $this->input->post('price');
            $type = $this->input->post('type');
            $lat = $this->input->post('lat');
            $lng = $this->input->post('lng');
            $type = $this->input->post('type');
            $arr_replace = "&quot;";
            $arr_needle = '"';
            $string_replaced_desc = str_replace($arr_needle, $arr_replace, $desc); 
            $desc_nl2br = $this->typography->nl2br_except_pre($string_replaced_desc);
            $time = date("Y-m-d H:i:s");

            $data = array(
                'name' => $name,
                'address' => $address,
                'district' => $district,
                'area' => $area,
                'description' => $desc_nl2br,
                'description_edit' => $desc,
                'bedrooms' => $bedrooms,
                'bathrooms' => $bathrooms,
                'price' => $price,
                'type' => $type,
                'lat' => $lat,
                'lng' => $lng,
                'type' => $type,
                'updated_at' => $time,
            );

            $query = $this->db->where('id', $id)
                                ->where('user_id', $_SESSION['user_id']);
            return $this->db->update('listings', $data);       
        }

        public function delete($id)
        {   
            $user_id = $_SESSION['user_id'];
            $query = $this->db->delete('listings', array(
                'id' => $id, 
                'user_id' => $user_id
                )
            );
        }

        public function update_click_count($new_click_count, $slug)
        {
            $data = array(
                'click_count' => $new_click_count
            );

            $query = $this->db->where('slug', $slug);
            return $this->db->update('listings', $data);              
        }

        public function get_user_listings()
        {   
            $user_id = $_SESSION['user_id'];
            $query = $this->db->select('id, name, user_id, district, bedrooms, bathrooms, area, price, type, image, slug, created_at')
                            ->order_by('id', 'desc')
                            ->where('user_id', $user_id)
                            ->get('listings');
            return $query->result_array();                
        }          

        public function get_listings($id = FALSE)
        {   
            if ($id === FALSE) {
                $query = $this->db->select('name, user_id, district, area, image, slug, type, price, bedrooms, bathrooms, created_at')
                                ->order_by('id', 'desc')
                                ->get('listings');
                return $query->result_array();     
            }           

            $query = $this->db->select('name, user_id, district, area, image, slug, type, price, bedrooms, bathrooms, created_at')
                                ->where('user_id', $id)
                                ->order_by('id', 'desc')
                                ->get('listings');
            return $query->result_array();  
        }

        public function get($slug)
        {
            $query = $this->db->select('name, user_id, address, district, area, description, type, price, image, lat, lng, slug, bedrooms, bathrooms, click_count, created_at')
                            ->where('slug', $slug)
                            ->get('listings');
            return $query->row_array();                
                
        }

        public function verify_ownership($id)
        {   
            $user_id = $_SESSION['user_id'];
            $array = array('id' => $id, 'user_id' => $user_id);
            $query = $this->db->select('id')
                        ->where($array)
                        ->get('listings');
            $count = count($query->result());
            return $count;            
        }

        public function get_listing($id)
        {
            $user_id = $_SESSION['user_id'];
            $array = array('id' => $id, 'user_id' => $user_id);
            $query = $this->db->select('id, name, user_id, address, district, area, description_edit, image, lat, lng, price, type, slug, bedrooms, bathrooms, click_count, created_at')
                        ->where($array)
                        ->get('listings');
            return $query->row_array();                        
        }

        public function search($limit, $start, $district, $area, $rooms, $baths, $type, $price_min, $price_max)
        {   
            $this->db->limit($limit, $start);
            // check if user has logged in
            if (isset($_SESSION['user_id'])) {
                $user_id = $_SESSION['user_id'];
            // only display listings not uploaded by the user on this page    
                $this->db->select('name, user_id, district, area, price, type, bathrooms, bedrooms,  image, slug, created_at')   
                        ->where('user_id !=', $user_id); 
            }
            
            $this->db->select('name, user_id, district, area, price, type, bathrooms, bedrooms,  image, slug, created_at');

            if ($district != 0) {
                $this->db->where('district', $district);
            }

            if ($area != 0) {
                $this->db->where('area', $area);
            }
            
            if ($rooms != 0) {
                $this->db->where('bedrooms', $rooms);
            }

            if ($baths != 0) {
                $this->db->where('bathrooms', $baths);
            }

            if ($type != 0) {
                $this->db->where('type', $type);
            }
            
            if ($price_min != 0) {
                $this->db->where('price >=', $price_min);
            }
            
            if ($price_max != 0) {
                $this->db->where('price <=', $price_max);
            }            

            $this->db->order_by('id', 'desc');
            $query = $this->db->get('listings');
            return $query->result_array();
        }

        public function count_search($district, $area, $rooms, $baths, $type, $price_min, $price_max)
        {   
            $this->db->select('id');

            if ($district != 0) {
                $this->db->where('district', $district);
            }

            if ($area != 0) {
                $this->db->where('area', $area);
            }
            
            if ($rooms != 0) {
                $this->db->where('bedrooms', $rooms);
            }

            if ($baths != 0) {
                $this->db->where('bathrooms', $baths);
            }

            if ($type != 0) {
                $this->db->where('type', $type);
            }
            
            if ($price_min != 0) {
                $this->db->where('price >=', $price_min);
            }
            
            if ($price_max != 0) {
                $this->db->where('price <=', $price_max);
            }            

            $query = $this->db->get('listings');                   
            $count = count($query->result());
            return $count;
        }        

}        
