<?php
class District_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }

        public function create()
        {
            $name = $this->input->post('name');
            $time = date("Y-m-d H:i:s");
            $data = [
            'name' => $name,    
            'created_at' => $time,
            ]; 

            return $this->db->insert('districts', $data);
        }     
        
        public function get()
        {   
            $query = $this->db->select('id, name')
                    ->get('districts');
            return $query->result_array();    
        }   

        public function get_district($id)
        {   
            $query = $this->db->select('id, name')
                    ->where('id', $id)
                    ->get('districts');
            return $query->row_array();    
        }           

        public function update()
        {   
            $id = $this->input->post('id');
            $name = $this->input->post('name');
            $time = date("Y-m-d H:i:s");
            
            $data = [
            'name' => $name,        
            'updated_at' => $time,
            ];

            $query = $this->db->where('id', $id);
            return $this->db->update('districts', $data);                 
        }

        public function delete()
        {   
            $id = $this->input->post('id');
            $query= $this->db->delete('districts', array('id' => $id));
            return $query;
        }

}        