<?php
class Messages_model extends CI_Model {

    // store message
    public function create($receiver_id)
    {   
        $msg = $this->input->post('message');
        $time = date("Y-m-d H:i:s");
        $sender_id = $_SESSION['user_id'];

        $data = [
            'message' => $msg,    
            'sender_id' => $sender_id,
            'receiver_id' => $receiver_id,
            'created_at' => $time,    
        ];

        return $this->db->insert('messages', $data);
    }

    public function get_other_user_name($id)
    {
        $query = $this->db->select('id, name, email')
                    ->where('id', $id)
                    ->get('users');
        return $query->row_array();   
    }

    // get other user in chat details
    public function get_user($receiver_id)
    {   
        $query = $this->db->select('id, name, email')
                        ->where('id', $receiver_id)
                        ->get('users');
        return $query->row_array();    
    }          

    public function get_messages()
    {
        $query = $this->db->distinct()
                        ->select('id, sender_id, receiver_id, message, created_at')
                        ->where('receiver_id', $_SESSION['user_id'])
                        ->or_where('sender_id', $_SESSION['user_id'])
                        ->get('messages');
        return $query->result_array();        
    }

    public function get_chat($id, $count_result)
    {   
        /*1PM 2nd Aug*/
        // check if session exists
        if (isset($_SESSION['user_id'])){
            $owner_id = $_SESSION['user_id'];
        }

        // get any messages that exist even if user did not initiate conversation
        if ($count_result == 0) {
            $query = $this->db->select('id, sender_id, receiver_id, message, created_at')
                        ->group_start()
                            ->where('receiver_id', $owner_id)
                            ->where('sender_id', $id)
                            ->or_group_start()
                                ->where('receiver_id', $id)
                                ->where('sender_id', $owner_id)
                            ->group_end()
                        ->group_end()
                    ->get('messages');
            return $query->result_array();                       
        }

        // if user has communicated with other user before then get all interactions
        $query = $this->db->select('id, sender_id, receiver_id, message, created_at')
                    ->group_start()
                        ->where('receiver_id', $owner_id)
                        ->where('sender_id', $id)
                        ->group_start()
                            ->where('sender_id', $owner_id)
                            ->where('receiver_id', $id)
                        ->group_end()
                    ->group_end()
                ->get('messages'); 
        return $query->result_array();                   
    }

    public function count_chat($id)
    {   
        /*1PM 2nd Aug*/
        if (isset($_SESSION['user_id'])){
            $owner_id = $_SESSION['user_id'];
        }

        // count messages in chat
        $query = $this->db->select('id, sender_id, receiver_id, message, created_at')
                    ->group_start()
                        ->where('receiver_id', $owner_id)
                        ->where('sender_id', $id)
                        ->group_start()
                            ->where('sender_id', $owner_id)
                            ->where('receiver_id', $id)
                        ->group_end()
                    ->group_end()
                ->get('messages'); 
        $count = count($query->result());
        return $count;                   
    }

    public function get_chat_details($id)
    {
        $query = $this->db->select('id, name')
                    ->where('id', $id)
                ->get('users');
        return $query->row_array();            
    }

    // get all user ids except logged in suer
    public function get_chatters()
    {
        if (isset($_SESSION['user_id'])){
            $owner_id = $_SESSION['user_id'];
        }

        $this->db->select('sender_id, receiver_id')
                    ->where('sender_id !=', $owner_id)
                    ->or_where('receiver_id !=', $owner_id)
                    ->get('messages');
        return $query->result_array();
    }

    // showing who sent the last message on chat page
    // get all interactions (sent from and received from)
    // all those who've sent the user a message
    public function get_receieved_interactions()
    {
        $owner_id = $_SESSION['user_id'];

        $query = $this->db->select('sender_id')
                    ->where('receiver_id', $owner_id)
                    ->get('messages');
        return $query->result_array();
    }

    // all those the user has sent messages to
    public function get_sent_interactions()
    {
        $owner_id = $_SESSION['user_id'];

        $query = $this->db->select('receiver_id')
                    ->where('sender_id', $owner_id)
                    ->get('messages');
        return $query->result_array();
    }    

    // get latest message time
    public function get_latest_msg_time($id)
    {
        $owner_id = $_SESSION['user_id'];

        $query = $this->db->select('MAX(created_at) AS created')
                        ->group_start()
                            ->where('receiver_id', $owner_id)
                            ->where('sender_id', $id)
                            ->or_group_start()
                                ->where('receiver_id', $id)
                                ->where('sender_id', $owner_id)
                            ->group_end()
                        ->group_end()
                    ->get('messages');
        return $query->row_array();            
    }

    // get latest message information
    public function get_latest_msg_info($id, $each_created_time)
    {
        $owner_id = $_SESSION['user_id'];

        $query = $this->db->select('id, message, sender_id, receiver_id, read_status, created_at')
                        ->where('created_at', $each_created_time)
                        ->group_start()
                            ->where('receiver_id', $owner_id)
                            ->where('sender_id', $id)
                            ->or_group_start()
                                ->where('receiver_id', $id)
                                ->where('sender_id', $owner_id)
                            ->group_end()
                        ->group_end()
                    ->get('messages');
        return $query->row_array();            
    }    

}    