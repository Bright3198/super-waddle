<?php
class Auth_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }

        public function auth($email)
        {
            $query = $this->db->select('id, name, email, password, permissions')
                                ->where('email', $email)
                                ->get('users');
            return $query->row_array(); 
        }

        public function check_user_exists($email)
        {
            $query = $this->db->select('name, email, password')
                                ->where('name', $email)
                                ->or_where('email', $email)
                                ->get('users');
            $count = count($query->result());
            return($count);       
        }          

        public function create_user($permissions)
        {   
            $time = date("Y-m-d H:i:s"); 
            $data = array(
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'created_at' => $time,
                'permissions' => $permissions,
                'password' => password_hash($this->input->post('password'),PASSWORD_DEFAULT)
            );

            return $this->db->insert('users', $data);
        }        
        
        public function update_name()
        {
            $time = date("Y-m-d H:i:s");
            $id = $this->input->post('id');
            $data = array(
                'name' => $this->input->post('name'),
                'updated_at' => $time,
            );

            $query = $this->db->where('id', $id)
                              ->where('email', $_SESSION['user_email']);
            return $this->db->update('users', $data);
        }        
        
        public function update_password()
        {
            $time = date("Y-m-d H:i:s");
            $id = $this->input->post('id');
            $new_password = $this->input->post('passconf');
            $data = array(
                'password' => password_hash($new_password, PASSWORD_DEFAULT),
                'updated_at' => $time,
            );

            $query = $this->db->where('id', $id)
                              ->where('email', $_SESSION['user_email']);
            return $this->db->update('users', $data);
        }                   

}        