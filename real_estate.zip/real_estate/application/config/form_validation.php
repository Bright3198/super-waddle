<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| Form Validation Rules
| -------------------------------------------------------------------
| This file contains an array of form validation rules
*/

$config = array(
		
		//SIGNUP Validation
		'auth/signup' => array(
			array(
					'field' => 'name',
					'label' => 'Name',
					'rules' => 'required|alpha_dash_spaces',
					'errors' => array(
						'required' => 'You cannot setup an account without a name',
						'alpha_dash_spaces' => 'Your name may only contain letters, numbers, spaces, underscores, and dashes.',
					),
			),

			array(
					'field' => 'email',
					'label' => 'Email',
					'rules' => 'required|valid_email|is_unique[users.email]',	
					'errors' => array(
						'valid_email' => 'Invalid Email given',
						'required' => 'You cannot setup an account without an email',
						'is_unique' => 'Email already in use!'
					),
			),

			array(
				'field' => 'password',
				'label' => 'Password',
				'rules' => 'required',	
				'errors' => array(
					'required' => 'You cannot setup an account without a password',
			),
		),			

	),
		//LOGIN Validation
        'auth/login' => array(
			array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'required|callback_user_exists_check|valid_email',
                'errors' => array(
					'valid_email' => 'Invalid Email given',
                    'required' => 'Email required',
                    'user_exists_check' => "The %s you've entered doesn't match any account.", 
                ),
        ),

            array(
				'field' => 'password',
				'label' => 'Password',
				'rules' => 'callback_password_check|required',
				'errors' => array(
					'password_check' => 'The %s you entered is incorrect.',
					'required' => 'Please enter your %s'
                    )
            )
		),

		//UPLOAD LISTING Validation
        'upload/listing' => array(
			array(
                'field' => 'name',
                'label' => 'Name',
                'rules' => 'required',
                'errors' => array(
                    'required' => '%s required', 
                ),
        	),

            array(
				'field' => 'address',
				'label' => 'Address',
				'rules' => 'required',
				'errors' => array(
					'required' => 'The %s of the property is required.'
                    )
			),
				
			array(
				'field' => 'description',
				'label' => 'Description',
				'rules' => 'required',
				'errors' => array(
					'required' => 'The %s of the property is required.'
					)
			),

			array(
				'field' => 'bedrooms',
				'label' => 'Bedrooms',
				'rules' => 'required',
				'errors' => array(
					'required' => 'Please specify the number of %s.'
					)
			),
			
			array(
				'field' => 'bathrooms',
				'label' => 'Bathrooms',
				'rules' => 'required',
				'errors' => array(
					'required' => 'The %s of the property is required.'
					)
			),	
			
			array(
				'field' => 'district',
				'label' => 'District',
				'rules' => 'required',
				'errors' => array(
					'required' => 'The %s the property is located in is required.'
					)
			),
			
			array(
				'field' => 'area',
				'label' => 'Area',
				'rules' => 'required',
				'errors' => array(
					'required' => 'The %s the property is located in is required.'
					)
			),
			
			array(
				'field' => 'type',
				'label' => 'Contract Type',
				'rules' => 'required|in_list[Rent,Sale]',
				'errors' => array(
					'required' => 'Please specify the %s (For Sale or For Rent).',
					'in_list' => 'Select appropriate contract type here'
					)
			),			

			array(
				'field' => 'price',
				'label' => 'Price',
				'rules' => 'required',
				'errors' => array(
					'required' => 'Please specify the %s.'
					)
			),				
			
        ),

		//UPDATE LISTING Validation
        'listings/update' => array(
			array(
                'field' => 'name',
                'label' => 'Name',
                'rules' => 'required',
                'errors' => array(
                    'required' => '%s required', 
                ),
        	),

            array(
				'field' => 'address',
				'label' => 'Address',
				'rules' => 'required',
				'errors' => array(
					'required' => 'The %s of the property is required.'
                    )
			),
				
			array(
				'field' => 'description',
				'label' => 'Description',
				'rules' => 'required',
				'errors' => array(
					'required' => 'The %s of the property is required.'
					)
			),

			array(
				'field' => 'bedrooms',
				'label' => 'Bedrooms',
				'rules' => 'required|greater_than_equal_to[1]',
				'errors' => array(
					'required' => 'Please specify the number of %s.',
					'greater_than_equal_to' => 'Specify a valid %s number'
					)
			),
			
			array(
				'field' => 'bathrooms',
				'label' => 'Bathrooms',
				'rules' => 'required|greater_than_equal_to[1]',
				'errors' => array(
					'required' => 'Please specify the number of %s.',
					'greater_than_equal_to' => 'Specify a valid %s number'
					)
			),	
			
			array(
				'field' => 'district',
				'label' => 'District',
				'rules' => 'required',
				'errors' => array(
					'required' => 'The %s the property is located in is required.'
					)
			),	
			
			array(
				'field' => 'area',
				'label' => 'Area',
				'rules' => 'required',
				'errors' => array(
					'required' => 'The %s the property is located in is required.'
					)
			),
			
			array(
				'field' => 'type',
				'label' => 'Contract Type',
				'rules' => 'required|in_list[Rent,Sale]',
				'errors' => array(
					'required' => 'Please specify the %s (For Sale or For Rent).',
					'in_list' => 'Select appropriate contract type here'
					)
			),			

			array(
				'field' => 'price',
				'label' => 'Price',
				'rules' => 'required|numeric',
				'errors' => array(
					'required' => 'Please specify the %s.',
					'numeric' => 'Enter your price as a number and not words',				
				),
			),			
			
        ),		
		
		//SUBSCRIPTION Validation
		'subscription/store' => array(
			array(
                'field' => 'district',
                'label' => 'District',
                'rules' => 'required',
                'errors' => array(
                    'required' => '%s required', 
                ),
        	),

		),
		
		//MESSAGE Validation
		'messages/store' => array(
			array(
                'field' => 'message',
                'label' => 'Message',
                'rules' => 'required',
                'errors' => array(
                    'required' => '%s cannot be blank', 
                ),
        	),
		),
		
		//DISTRICT Validation
		'admin/store_district' => array(
			array(
				'field' => 'name',
				'label' => 'District',
				'rules' => 'required|is_unique[districts.name]|min_length[4]',	
				'errors' => array(
					'required' => '%s name cannot be blank',
					'is_unique' => '%s already exists!',
					'min_length' => '%s name should have at least 4 characters'
				),
			),
		),	

		//UPDATE DISTRICT Validation
		'district/update' => array(
			array(
				'field' => 'name',
				'label' => 'District',
				'rules' => 'required|min_length[4]',	
				'errors' => array(
					'required' => '%s name cannot be blank',
					'is_unique' => '%s already exists!',
					'min_length' => '%s name should have at least 4 characters'
				),
			),
		),			

		//AREA Validation
		'admin/store_area' => array(
			array(
				'field' => 'name',
				'label' => 'Area',
				'rules' => 'required|is_unique[areas.name]',	
				'errors' => array(
					'required' => '%s name cannot be blank',
					'is_unique' => '%s already exists!'
				),
			),		
		),

		//UPDATE AREA Validation
		'area/update' => array(
			array(
				'field' => 'name',
				'label' => 'Area',
				'rules' => 'required|min_length[4]',	
				'errors' => array(
					'required' => '%s name cannot be blank',
					'min_length' => '%s name should have at least 4 characters'
				),
			),		
		),		

		'error_prefix' => '<div class="alert alert-danger">',
		'error_suffix' => '</div>',			
);
